# AJAX 403 Forbidden Error Fix

## Problem Description
The SMO Social plugin was experiencing a 403 Forbidden error when making AJAX requests to `admin-ajax.php`, specifically for the `smo_get_platform_status` action. The error occurred because of a nonce mismatch between the JavaScript frontend and the PHP backend.

## Root Cause Analysis
The issue was caused by a mismatch in nonce action names:

1. **JavaScript (admin.js)** was sending: `smo_social_nonce`
2. **PHP Backend (BaseAjaxHandler.php)** was expecting: `smo-social-admin-nonce`

This mismatch caused the nonce verification in `BaseAjaxHandler::verify_request()` to fail, resulting in a 403 Forbidden error.

## Files Affected
- `includes/Admin/Ajax/BaseAjaxHandler.php` - Contains the nonce action definition
- `includes/Admin/AssetManager.php` - Localizes the JavaScript with the correct nonce
- `assets/js/admin.js` - Sends AJAX requests with the nonce
- `includes/Admin/Ajax/PlatformAjax.php` - Extends BaseAjaxHandler and was affected by the mismatch

## Solution Applied
Updated the nonce action in `BaseAjaxHandler.php` to match the frontend:

```php
// Before (line 18)
protected $nonce_action = 'smo-social-admin-nonce';

// After (line 18)
protected $nonce_action = 'smo_social_nonce';
```

## Impact
This fix resolves the 403 Forbidden error for all AJAX endpoints that extend `BaseAjaxHandler`, including:
- `smo_get_platform_status` - Platform status loading
- `smo_connect_platform` - Platform connection
- `smo_disconnect_platform` - Platform disconnection
- `smo_test_platform` - Platform testing
- `smo_save_platform_credentials` - Credential saving
- `smo_save_platform_settings` - Platform settings
- `smo_refresh_platform_health` - Health check refresh
- `smo_get_platform_health_details` - Health details

## Verification
A test script (`test_ajax_fix.php`) was created to verify the fix works correctly. The test confirms that:
1. Nonce verification now passes successfully
2. The `smo_get_platform_status` AJAX endpoint should work without 403 errors
3. All other AJAX endpoints extending BaseAjaxHandler are also fixed

## Notes
- The `WorkflowAjax.php` class uses a different nonce action (`smo_users_nonce`) which is intentional and remains unchanged
- This fix maintains backward compatibility with existing JavaScript code
- No database changes were required

## Testing
To test the fix:
1. Load the SMO Social admin page
2. Check browser console for AJAX errors
3. Verify that platform status loads correctly
4. Test platform connection/disconnection functionality

The 403 Forbidden error should no longer appear in the browser console.
