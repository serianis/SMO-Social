<?php
namespace SMO_Social\Admin\Ajax;

if (!defined('ABSPATH')) {
    exit;
}

/**
 * Base abstract class for AJAX handlers
 * 
 * Provides common functionality for nonce verification, 
 * permission checking, and JSON response formatting.
 */
abstract class BaseAjaxHandler {
    
    /**
     * nonce action name
     * @var string
     */
    protected $nonce_action = 'smo_social_nonce';

    /**
     * Required capability to execute this handler
     * @var string
     */
    protected $capability = 'manage_options';

    /**
     * Register AJAX actions
     * This method must be implemented by child classes to register their hooks
     */
    abstract public function register();

    /**
     * Verify request security (nonce and permissions)
     * 
     * @param bool $check_nonce Whether to verify nonce
     * @return bool True if valid, sends JSON error and dies if invalid
     */
    protected function verify_request($check_nonce = true) {
        // 1. Check permissions
        if (!current_user_can($this->capability)) {
            $this->send_error(__('Insufficient permissions.', 'smo-social'), 403);
            return false;
        }

        // 2. Check nonce
        if ($check_nonce) {
            $nonce = isset($_REQUEST['nonce']) ? $_REQUEST['nonce'] : '';
            if (!wp_verify_nonce($nonce, $this->nonce_action)) {
                $this->send_error(__('Security check failed.', 'smo-social'), 403);
                return false;
            }
        }

        return true;
    }

    /**
     * clear a specific text input
     * @param string $key Request key
     * @return string Sanitized text
     */
    protected function get_text($key, $default = '') {
        return isset($_REQUEST[$key]) ? sanitize_text_field($_REQUEST[$key]) : $default;
    }

    /**
     * Get integer input
     * @param string $key Request key
     * @return int Sanitized integer
     */
    protected function get_int($key, $default = 0) {
        return isset($_REQUEST[$key]) ? absint($_REQUEST[$key]) : $default;
    }

    /**
     * Test wrapper for verify_request method
     *
     * This public method allows testing of the protected verify_request method
     * without using deprecated reflection setAccessible functionality.
     *
     * @param bool $check_nonce Whether to verify nonce
     * @return bool True if valid, false otherwise
     */
    public function test_verify_request($check_nonce = true) {
        return $this->verify_request($check_nonce);
    }

    /**
     * Send JSON success response
     * 
     * @param mixed $data Data to send
     * @param string $message Optional message
     */
    protected function send_success($data = null, $message = '') {
        $response = ['success' => true];
        if ($data !== null) {
            $response['data'] = $data;
        }
        if ($message) {
            $response['message'] = $message;
        }
        wp_send_json_success($response);
    }

    /**
     * Send JSON error response
     * 
     * @param string $message Error message
     * @param int $code HTTP status code
     * @param mixed $data Additional data
     */
    protected function send_error($message, $code = 400, $data = null) {
        $response = [
            'success' => false,
            'message' => $message,
            'code' => $code
        ];
        if ($data !== null) {
            $response['data'] = $data;
        }
        wp_send_json_error($response, $code);
    }
}
