<?php
/**
 * Database Manager for SMO Social
 *
 * Handles database creation, migration, and maintenance
 * Includes query optimization and caching mechanisms
 *
 * @package SMO_Social
 * @subpackage Core
 * @since 1.0.0
 */

namespace SMO_Social\Core;

if (!defined('ABSPATH')) {
    exit;
}

// Include WordPress function stubs for compatibility
require_once __DIR__ . '/../wordpress-functions.php';
require_once __DIR__ . '/../consolidated-db-stubs.php';
require_once __DIR__ . '/CacheManager.php';
require_once __DIR__ . '/DatabaseConnectionPool.php';
require_once __DIR__ . '/DatabaseConnectionCleanup.php';

/**
 * Database Manager
 */
class DatabaseManager {
    /**
     * @var DatabaseConnectionPool|null Database connection pool instance
     */
    private static $connection_pool = null;

    /**
     * Initialize the database connection pool
     */
    private static function initialize_connection_pool() {
        if (self::$connection_pool === null) {
            $pool_config = [
                'max_pool_size' => 10,
                'connection_timeout' => 300
            ];

            // Get pool size from settings if available
            $settings = get_option('smo_social_settings', []);
            if (isset($settings['db_pool_size']) && is_numeric($settings['db_pool_size'])) {
                $pool_config['max_pool_size'] = max(1, min(20, intval($settings['db_pool_size'])));
            }

            self::$connection_pool = new DatabaseConnectionPool([], $pool_config['max_pool_size']);
            self::$connection_pool->set_max_pool_size($pool_config['max_pool_size']);
        }
    }

    /**
     * Get a database connection from the pool
     *
     * @return resource|null Database connection
     */
    public static function get_db_connection() {
        if (self::$connection_pool === null) {
            self::initialize_connection_pool();
        }

        return self::$connection_pool->get_connection();
    }

    /**
     * Release a database connection back to the pool
     *
     * @param resource $connection Database connection
     */
    public static function release_db_connection($connection) {
        if (self::$connection_pool !== null) {
            self::$connection_pool->release_connection($connection);
        }
    }

    /**
     * Get database connection pool statistics
     *
     * @return array Pool statistics
     */
    public static function get_connection_pool_stats() {
        if (self::$connection_pool === null) {
            self::initialize_connection_pool();
        }

        return self::$connection_pool->get_stats();
    }

    /**
     * Cleanup database connection pool
     */
    public static function cleanup_connection_pool() {
        if (self::$connection_pool !== null) {
            self::$connection_pool->cleanup_idle_connections();
        }
    }

    /**
     * Get database connection cleanup instance
     *
     * @return DatabaseConnectionCleanup
     */
    public static function get_connection_cleanup() {
        static $cleanup_instance = null;

        if ($cleanup_instance === null) {
            $cleanup_instance = new DatabaseConnectionCleanup();
        }

        return $cleanup_instance;
    }

    /**
     * Perform comprehensive connection cleanup
     *
     * @return array Cleanup results
     */
    public static function perform_comprehensive_cleanup() {
        $cleanup = self::get_connection_cleanup();
        return [
            'idle_cleanup' => $cleanup->cleanup_idle_connections(),
            'automatic_cleanup' => $cleanup->automatic_cleanup(),
            'health_stats' => $cleanup->get_health_statistics(),
            'validation_results' => $cleanup->perform_comprehensive_validation()
        ];
    }

    /**
     * Monitor connection health
     *
     * @return array Health monitoring results
     */
    public static function monitor_connection_health() {
        $cleanup = self::get_connection_cleanup();
        return [
            'health_checks' => $cleanup->check_connection_health_with_timeout(),
            'monitoring_results' => $cleanup->monitor_connection_states(),
            'pool_stats' => $cleanup->get_connection_pool_stats()
        ];
    }

    /**
     * Initialize database on plugin activation
     */
    public static function activate() {
        // Create database schema
        self::create_database_schema();
        
        // Create default settings
        self::create_default_settings();
        
        // Schedule cron jobs
        self::schedule_cron_jobs();
        
        // Set plugin version
        update_option('smo_social_db_version', '1.0.0');
        
        error_log('SMO Social: Database activated successfully');
    }
    
    /**
     * Update database on plugin update
     */
    public static function update() {
        $current_version = get_option('smo_social_db_version', '0.0.0');
        
        if (version_compare($current_version, '1.0.0', '<')) {
            self::create_database_schema();
            self::migrate_data();
            update_option('smo_social_db_version', '1.0.0');
        }
        
        error_log('SMO Social: Database updated to version ' . $current_version);
    }
    
    /**
     * Create complete database schema
     */
    public static function create_database_schema() {
        // Include the database schema classes
        require_once __DIR__ . '/DatabaseSchema.php';
        require_once __DIR__ . '/DatabaseSchemaExtended.php';

        // Create all enhanced tables
        DatabaseSchema::create_enhanced_tables();

        // Create extended tables (Content Organizer tables)
        DatabaseSchemaExtended::create_extended_tables();

        // Create content organizer tables (from Database namespace)
        if (file_exists(__DIR__ . '/../Database/DatabaseSchema.php')) {
            require_once __DIR__ . '/../Database/DatabaseSchema.php';
            \SMO_Social\Database\DatabaseSchema::create_tables();
        }

        // Create performance indexes
        DatabaseSchema::create_performance_indexes();

        // Update existing tables if needed
        DatabaseSchemaExtended::update_existing_tables();

        // Create normalized tables migration if needed
        self::create_normalized_tables_migration();

        error_log('SMO Social: Database schema created successfully');
    }
    
    /**
     * Create default plugin settings
     */
    private static function create_default_settings() {
        // Default general settings
        add_option('smo_social_settings', array(
            'enabled' => true,
            'timezone' => 'UTC',
            'date_format' => 'Y-m-d H:i:s',
            'queue_interval' => 5,
            'max_retries' => 3,
            'retry_delay' => 300,
            'ai_enabled' => true,
            'ai_tone' => 'professional',
            'ai_variants' => false,
            'data_retention' => 365,
            'log_level' => 'info'
        ));
        
        // Default advanced scheduling settings
        add_option('smo_advanced_scheduling', array(
            'auto_publish_enabled' => false,
            'default_slots' => array(),
            'platform_settings' => array(),
            'content_rules' => array(
                'auto_categorize' => true,
                'auto_optimize' => true,
                'auto_hashtags' => true,
                'max_queue_size' => 100,
                'processing_interval' => 5
            ),
            'fallback_settings' => array()
        ));
        
        // Default auto-publish settings
        add_option('smo_auto_publish_settings', array(
            'enabled' => false,
            'platforms' => array(),
            'post_types' => array('post'),
            'categories' => array(),
            'delay_minutes' => 0,
            'require_featured_image' => false,
            'auto_hashtags' => true,
            'auto_optimize' => true,
            'custom_message' => ''
        ));
        
        // Default enabled platforms
        add_option('smo_social_enabled_platforms', array());
        
        // Default AI provider settings
        add_option('smo_social_ai_settings', array(
            'primary_provider' => 'huggingface',
            'huggingface_api_key' => '',
            'localhost_api_url' => '',
            'custom_api_url' => '',
            'custom_api_key' => '',
            'fallback_enabled' => true
        ));
        
        error_log('SMO Social: Default settings created');
    }
    
    /**
     * Schedule necessary cron jobs
     */
    private static function schedule_cron_jobs() {
        // Analytics processing (daily)
        if (!\wp_next_scheduled('smo_analytics_daily_cron')) {
            \wp_schedule_event(time(), 'daily', 'smo_analytics_daily_cron');
        }
        
        // Auto-publish processing (every 5 minutes)
        if (!\wp_next_scheduled('smo_auto_publish_cron')) {
            \wp_schedule_event(time(), 'every_5_minutes', 'smo_auto_publish_cron');
        }
        
        // Queue processing (every minute)
        if (!\wp_next_scheduled('smo_process_queue_cron')) {
            \wp_schedule_event(time(), 'every_minute', 'smo_process_queue_cron');
        }
        
        // Cleanup old data (weekly)
        if (!\wp_next_scheduled('smo_cleanup_cron')) {
            \wp_schedule_event(time(), 'weekly', 'smo_cleanup_cron');
        }
        
        error_log('SMO Social: Cron jobs scheduled');
    }
    
    /**
     * Migrate data from old schema (if upgrading)
     */
    private static function migrate_data() {
        global $wpdb;
        
        // Check if old tables exist and migrate data
        $old_tables = array(
            $wpdb->prefix . 'smo_scheduled_posts',
            $wpdb->prefix . 'smo_platform_tokens',
            $wpdb->prefix . 'smo_analytics'
        );
        
        foreach ($old_tables as $table) {
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            if ($table_exists) {
                error_log("SMO Social: Found old table $table, data migration may be needed");
            }
        }
        
        // Migrate to new enhanced tables if needed
        // This would contain specific migration logic
        
        error_log('SMO Social: Data migration completed');
    }
    
    /**
     * Deactivate plugin and clean up
     */
    public static function deactivate() {
        // Clear scheduled cron jobs
        \wp_clear_scheduled_hook('smo_analytics_daily_cron');
        \wp_clear_scheduled_hook('smo_auto_publish_cron');
        \wp_clear_scheduled_hook('smo_process_queue_cron');
        \wp_clear_scheduled_hook('smo_cleanup_cron');
        
        error_log('SMO Social: Plugin deactivated, cron jobs cleared');
    }
    
    /**
     * Uninstall plugin and remove all data
     */
    public static function uninstall() {
        // Remove all plugin options
        delete_option('smo_social_settings');
        delete_option('smo_advanced_scheduling');
        delete_option('smo_auto_publish_settings');
        delete_option('smo_social_enabled_platforms');
        delete_option('smo_social_ai_settings');
        delete_option('smo_social_db_version');
        
        // Remove all plugin tables
        self::drop_all_tables();
        
        // Clear all cron jobs
        \wp_clear_scheduled_hook('smo_analytics_daily_cron');
        \wp_clear_scheduled_hook('smo_auto_publish_cron');
        \wp_clear_scheduled_hook('smo_process_queue_cron');
        \wp_clear_scheduled_hook('smo_cleanup_cron');
        
        error_log('SMO Social: Plugin uninstalled, all data removed');
    }
    
    /**
     * Drop all plugin tables
     */
    private static function drop_all_tables() {
        global $wpdb;
        
        $tables = array(
            $wpdb->prefix . 'smo_posts_per_day_analytics',
            $wpdb->prefix . 'smo_auto_publish_content',
            $wpdb->prefix . 'smo_enhanced_templates',
            $wpdb->prefix . 'smo_team_members',
            $wpdb->prefix . 'smo_team_assignments',
            $wpdb->prefix . 'smo_network_groupings',
            $wpdb->prefix . 'smo_url_shorteners',
            $wpdb->prefix . 'smo_best_time_predictions',
            $wpdb->prefix . 'smo_image_editor_data',
            $wpdb->prefix . 'smo_reshare_queue',
            $wpdb->prefix . 'smo_enhanced_calendar',
            $wpdb->prefix . 'smo_team_calendar',
            $wpdb->prefix . 'smo_multisite_networks',
            $wpdb->prefix . 'smo_entity_platforms',
            $wpdb->prefix . 'smo_post_media',
            $wpdb->prefix . 'smo_transformation_rules',
            $wpdb->prefix . 'smo_transformation_variables'
        );
        
        foreach ($tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Also drop original tables if they exist
        $original_tables = array(
            $wpdb->prefix . 'smo_scheduled_posts',
            $wpdb->prefix . 'smo_platform_tokens',
            $wpdb->prefix . 'smo_analytics',
            $wpdb->prefix . 'smo_content_variants',
            $wpdb->prefix . 'smo_activity_logs',
            $wpdb->prefix . 'smo_content_templates',
            $wpdb->prefix . 'smo_queue',
            $wpdb->prefix . 'smo_post_platforms'
        );
        
        foreach ($original_tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
        
        // Drop content organizer tables
        $organizer_tables = array(
            $wpdb->prefix . 'smo_posts',
            $wpdb->prefix . 'smo_platforms',
            $wpdb->prefix . 'smo_content_categories',
            $wpdb->prefix . 'smo_content_category_relationships',
            $wpdb->prefix . 'smo_rss_feeds',
            $wpdb->prefix . 'smo_imported_content',
            $wpdb->prefix . 'smo_content_ideas',
            $wpdb->prefix . 'smo_content_sources'
        );
        
        foreach ($organizer_tables as $table) {
            $wpdb->query("DROP TABLE IF EXISTS $table");
        }
    }
    
    /**
     * Check if database needs updating
     */
    public static function needs_update() {
        $current_version = get_option('smo_social_db_version', '0.0.0');
        $required_version = '1.0.0';

        return version_compare($current_version, $required_version, '<');
    }

    /**
     * Repair database issues
     */
    public static function repair_database() {
        global $wpdb;
        
        $issues_fixed = array();
        
        // Check and fix table structure
        $missing_tables = self::get_database_status()['missing_tables'];
        if (!empty($missing_tables)) {
            self::create_database_schema();
            $issues_fixed[] = 'Created missing database tables';
        }
        
        // Fix cron jobs
        $scheduled_hooks = array(
            'smo_analytics_daily_cron',
            'smo_auto_publish_cron',
            'smo_process_queue_cron',
            'smo_cleanup_cron'
        );
        
        foreach ($scheduled_hooks as $hook) {
            if (!\wp_next_scheduled($hook)) {
                switch ($hook) {
                    case 'smo_analytics_daily_cron':
                        \wp_schedule_event(time(), 'daily', $hook);
                        break;
                    case 'smo_auto_publish_cron':
                    case 'smo_process_queue_cron':
                        \wp_schedule_event(time(), 'every_5_minutes', $hook);
                        break;
                    case 'smo_cleanup_cron':
                        \wp_schedule_event(time(), 'weekly', $hook);
                        break;
                }
                $issues_fixed[] = "Repaired cron job: $hook";
            }
        }
        
        // Fix missing options
        if (!get_option('smo_social_settings')) {
            self::create_default_settings();
            $issues_fixed[] = 'Recreated missing plugin settings';
        }
        
        return $issues_fixed;
    }

    /**
     * Get database status information with caching
     */
    public static function get_database_status() {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'database_status_cache';
        $cache_ttl = 300; // 5 minutes cache

        // Try to get cached status
        $cached_status = $cache_manager->get($cache_key);
        if ($cached_status !== false) {
            return $cached_status;
        }

        $tables = array(
            'posts_per_day_analytics' => $wpdb->prefix . 'smo_posts_per_day_analytics',
            'auto_publish_content' => $wpdb->prefix . 'smo_auto_publish_content',
            'enhanced_templates' => $wpdb->prefix . 'smo_enhanced_templates',
            'team_members' => $wpdb->prefix . 'smo_team_members',
            'team_assignments' => $wpdb->prefix . 'smo_team_assignments',
            'network_groupings' => $wpdb->prefix . 'smo_network_groupings',
            'url_shorteners' => $wpdb->prefix . 'smo_url_shorteners',
            'best_time_predictions' => $wpdb->prefix . 'smo_best_time_predictions',
            'image_editor_data' => $wpdb->prefix . 'smo_image_editor_data',
            'reshare_queue' => $wpdb->prefix . 'smo_reshare_queue',
            'enhanced_calendar' => $wpdb->prefix . 'smo_enhanced_calendar',
            'team_calendar' => $wpdb->prefix . 'smo_team_calendar',
            'multisite_networks' => $wpdb->prefix . 'smo_multisite_networks',
            'entity_platforms' => $wpdb->prefix . 'smo_entity_platforms',
            'post_media' => $wpdb->prefix . 'smo_post_media',
            'transformation_rules' => $wpdb->prefix . 'smo_transformation_rules',
            'transformation_variables' => $wpdb->prefix . 'smo_transformation_variables'
        );

        $status = array();
        $missing_tables = array();

        foreach ($tables as $name => $table) {
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            if ($exists) {
                $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
                $status[$name] = array(
                    'exists' => true,
                    'records' => intval($count),
                    'table_size' => self::get_table_size($table)
                );
            } else {
                $status[$name] = array(
                    'exists' => false,
                    'records' => 0,
                    'table_size' => '0 KB'
                );
                $missing_tables[] = $name;
            }
        }

        $result = array(
            'status' => $status,
            'missing_tables' => $missing_tables,
            'needs_update' => self::needs_update(),
            'current_version' => get_option('smo_social_db_version', '0.0.0'),
            'required_version' => '1.0.0'
        );

        // Cache the result
        $cache_manager->set($cache_key, $result, $cache_ttl);

        return $result;
    }

    /**
     * Get table size with caching
     */
    private static function get_table_size($table) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'table_size_' . md5($table);
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached size
        $cached_size = $cache_manager->get($cache_key);
        if ($cached_size !== false) {
            return $cached_size;
        }

        $result = $wpdb->get_row($wpdb->prepare(
            "SELECT
                ROUND(((data_length + index_length) / 1024 / 1024), 2) AS 'size_mb'
            FROM information_schema.TABLES
            WHERE table_schema = %s AND table_name = %s",
            DB_NAME,
            $table
        ));

        $size = $result ? $result->size_mb . ' MB' : 'Unknown';

        // Cache the result
        $cache_manager->set($cache_key, $size, $cache_ttl);

        return $size;
    }

    /**
     * Get batched table status information
     */
    public static function get_batched_table_status($table_names) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'batched_table_status_' . md5(serialize($table_names));
        $cache_ttl = 600; // 10 minutes cache

        // Try to get cached status
        $cached_status = $cache_manager->get($cache_key);
        if ($cached_status !== false) {
            return $cached_status;
        }

        $results = array();

        foreach ($table_names as $table_name) {
            $table = $wpdb->prefix . 'smo_' . $table_name;
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");

            if ($exists) {
                $count = $wpdb->get_var("SELECT COUNT(*) FROM $table");
                $results[$table_name] = array(
                    'exists' => true,
                    'records' => intval($count),
                    'table_size' => self::get_table_size($table)
                );
            } else {
                $results[$table_name] = array(
                    'exists' => false,
                    'records' => 0,
                    'table_size' => '0 KB'
                );
            }
        }

        // Cache the result
        $cache_manager->set($cache_key, $results, $cache_ttl);

        return $results;
    }

    /**
     * Get multiple table sizes in a single query
     */
    public static function get_multiple_table_sizes($table_names) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'multiple_table_sizes_' . md5(serialize($table_names));
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached sizes
        $cached_sizes = $cache_manager->get($cache_key);
        if ($cached_sizes !== false) {
            return $cached_sizes;
        }

        $results = array();

        foreach ($table_names as $table_name) {
            $table = $wpdb->prefix . 'smo_' . $table_name;
            $results[$table_name] = self::get_table_size($table);
        }

        // Cache the result
        $cache_manager->set($cache_key, $results, $cache_ttl);

        return $results;
    }

    /**
     * Create normalized tables migration
     */
    private static function create_normalized_tables_migration() {
        global $wpdb;

        // Check if normalized tables already exist
        $normalized_tables = [
            $wpdb->prefix . 'smo_entity_platforms',
            $wpdb->prefix . 'smo_post_media',
            $wpdb->prefix . 'smo_transformation_rules',
            $wpdb->prefix . 'smo_transformation_variables'
        ];

        foreach ($normalized_tables as $table) {
            $exists = $wpdb->get_var("SHOW TABLES LIKE '$table'");
            if (!$exists) {
                error_log("SMO Social: Normalized table $table does not exist, may need migration");
                return;
            }
        }

        // If tables exist, we need to migrate data from denormalized columns
        self::migrate_platform_relationships();
        self::migrate_media_attachments();
        self::migrate_transformation_data();

        error_log('SMO Social: Normalized tables migration completed');
    }

    /**
     * Migrate platform relationships to normalized structure
     */
    private static function migrate_platform_relationships() {
        global $wpdb;

        // Tables that contain platforms as text/longtext
        $tables_with_platforms = [
            'smo_network_groupings' => 'platforms',
            'smo_team_assignments' => 'platforms',
            'smo_auto_publish_content' => 'platforms',
            'smo_enhanced_templates' => 'platforms',
            'smo_reshare_queue' => 'platforms',
            'smo_enhanced_calendar' => 'platforms',
            'smo_team_calendar' => 'platforms'
        ];

        foreach ($tables_with_platforms as $table_name => $column_name) {
            $full_table_name = $wpdb->prefix . $table_name;
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$full_table_name'");

            if ($table_exists) {
                // Get all records with platform data
                $records = $wpdb->get_results("SELECT id, $column_name FROM $full_table_name WHERE $column_name IS NOT NULL AND $column_name != ''");

                foreach ($records as $record) {
                    $entity_id = $record->id;
                    $platforms_json = $record->{$column_name};

                    // Parse JSON platforms data
                    try {
                        $platforms = json_decode($platforms_json, true);
                        if (is_array($platforms)) {
                            foreach ($platforms as $platform_slug) {
                                if (!empty($platform_slug)) {
                                    // Insert into normalized table
                                    $wpdb->insert(
                                        $wpdb->prefix . 'smo_entity_platforms',
                                        [
                                            'entity_type' => $table_name,
                                            'entity_id' => $entity_id,
                                            'platform_slug' => sanitize_text_field($platform_slug),
                                            'created_at' => current_time('mysql')
                                        ],
                                        ['%s', '%d', '%s', '%s']
                                    );
                                }
                            }
                        }
                    } catch (\Exception $e) {
                        error_log("SMO Social: Error migrating platforms for $table_name record $entity_id: " . $e->getMessage());
                    }
                }
            }
        }
    }

    /**
     * Migrate media attachments to normalized structure
     */
    private static function migrate_media_attachments() {
        global $wpdb;

        // Tables that contain media_urls as text/longtext
        $tables_with_media = [
            'smo_posts' => 'media_urls',
            'smo_enhanced_calendar' => 'media_attachments'
        ];

        foreach ($tables_with_media as $table_name => $column_name) {
            $full_table_name = $wpdb->prefix . $table_name;
            $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$full_table_name'");

            if ($table_exists) {
                // Get all records with media data
                $records = $wpdb->get_results("SELECT id, $column_name FROM $full_table_name WHERE $column_name IS NOT NULL AND $column_name != ''");

                foreach ($records as $record) {
                    $post_id = $record->id;
                    $media_urls_text = $record->{$column_name};

                    // Parse comma-separated or JSON media URLs
                    $media_urls = [];
                    if (strpos($media_urls_text, '[') === 0) {
                        // JSON array format
                        try {
                            $media_urls = json_decode($media_urls_text, true);
                        } catch (\Exception $e) {
                            // Fall back to comma-separated
                            $media_urls = explode(',', $media_urls_text);
                        }
                    } else {
                        // Comma-separated format
                        $media_urls = explode(',', $media_urls_text);
                    }

                    $order = 0;
                    foreach ($media_urls as $media_url) {
                        $media_url = trim($media_url);
                        if (!empty($media_url)) {
                            // Determine media type from URL
                            $media_type = 'image';
                            if (preg_match('/\.(mp4|webm|ogg|mov)$/i', $media_url)) {
                                $media_type = 'video';
                            } elseif (preg_match('/\.(mp3|wav|ogg)$/i', $media_url)) {
                                $media_type = 'audio';
                            }

                            // Insert into normalized table
                            $wpdb->insert(
                                $wpdb->prefix . 'smo_post_media',
                                [
                                    'post_id' => $post_id,
                                    'media_url' => $media_url,
                                    'media_type' => $media_type,
                                    'media_order' => $order,
                                    'created_at' => current_time('mysql')
                                ],
                                ['%d', '%s', '%s', '%d', '%s']
                            );

                            $order++;
                        }
                    }
                }
            }
        }
    }

    /**
     * Migrate transformation data to normalized structure
     */
    private static function migrate_transformation_data() {
        global $wpdb;

        $table_name = $wpdb->prefix . 'smo_content_transformation_templates';
        $table_exists = $wpdb->get_var("SHOW TABLES LIKE '$table_name'");

        if ($table_exists) {
            // Get all records with transformation data
            $records = $wpdb->get_results("SELECT id, transformation_rules, variables FROM $table_name WHERE transformation_rules IS NOT NULL AND transformation_rules != ''");

            foreach ($records as $record) {
                $template_id = $record->id;

                // Migrate transformation rules
                try {
                    $transformation_rules = json_decode($record->transformation_rules, true);
                    if (is_array($transformation_rules)) {
                        $order = 0;
                        foreach ($transformation_rules as $rule_type => $rule_config) {
                            $wpdb->insert(
                                $wpdb->prefix . 'smo_transformation_rules',
                                [
                                    'template_id' => $template_id,
                                    'rule_type' => sanitize_text_field($rule_type),
                                    'rule_config' => json_encode($rule_config),
                                    'rule_order' => $order,
                                    'created_at' => current_time('mysql')
                                ],
                                ['%d', '%s', '%s', '%d', '%s']
                            );
                            $order++;
                        }
                    }
                } catch (\Exception $e) {
                    error_log("SMO Social: Error migrating transformation rules for template $template_id: " . $e->getMessage());
                }

                // Migrate variables
                try {
                    $variables = json_decode($record->variables, true);
                    if (is_array($variables)) {
                        foreach ($variables as $var_name => $var_data) {
                            $wpdb->insert(
                                $wpdb->prefix . 'smo_transformation_variables',
                                [
                                    'template_id' => $template_id,
                                    'variable_name' => sanitize_text_field($var_name),
                                    'variable_type' => isset($var_data['type']) ? sanitize_text_field($var_data['type']) : 'string',
                                    'default_value' => isset($var_data['default']) ? $var_data['default'] : '',
                                    'description' => isset($var_data['description']) ? $var_data['description'] : '',
                                    'created_at' => current_time('mysql')
                                ],
                                ['%d', '%s', '%s', '%s', '%s', '%s']
                            );
                        }
                    }
                } catch (\Exception $e) {
                    error_log("SMO Social: Error migrating transformation variables for template $template_id: " . $e->getMessage());
                }
            }
        }
    }

    /**
     * Get platforms for an entity using normalized structure
     */
    public static function get_entity_platforms($entity_type, $entity_id) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'entity_platforms_' . $entity_type . '_' . $entity_id;
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached platforms
        $cached_platforms = $cache_manager->get($cache_key);
        if ($cached_platforms !== false) {
            return $cached_platforms;
        }

        $table_name = $wpdb->prefix . 'smo_entity_platforms';
        $platforms = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT platform_slug, platform_config FROM $table_name
                WHERE entity_type = %s AND entity_id = %d
                ORDER BY created_at ASC",
                $entity_type,
                $entity_id
            )
        );

        $result = [];
        foreach ($platforms as $platform) {
            $result[] = [
                'slug' => $platform->platform_slug,
                'config' => $platform->platform_config ? json_decode($platform->platform_config, true) : null
            ];
        }

        // Cache the result
        $cache_manager->set($cache_key, $result, $cache_ttl);

        return $result;
    }

    /**
     * Get media attachments for a post using normalized structure
     */
    public static function get_post_media($post_id) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'post_media_' . $post_id;
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached media
        $cached_media = $cache_manager->get($cache_key);
        if ($cached_media !== false) {
            return $cached_media;
        }

        $table_name = $wpdb->prefix . 'smo_post_media';
        $media_items = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT media_url, media_type, media_order, metadata FROM $table_name
                WHERE post_id = %d
                ORDER BY media_order ASC",
                $post_id
            )
        );

        $result = [];
        foreach ($media_items as $media) {
            $result[] = [
                'url' => $media->media_url,
                'type' => $media->media_type,
                'order' => $media->media_order,
                'metadata' => $media->metadata ? json_decode($media->metadata, true) : null
            ];
        }

        // Cache the result
        $cache_manager->set($cache_key, $result, $cache_ttl);

        return $result;
    }

    /**
     * Get transformation rules for a template using normalized structure
     */
    public static function get_transformation_rules($template_id) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'transformation_rules_' . $template_id;
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached rules
        $cached_rules = $cache_manager->get($cache_key);
        if ($cached_rules !== false) {
            return $cached_rules;
        }

        $table_name = $wpdb->prefix . 'smo_transformation_rules';
        $rules = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT rule_type, rule_config, rule_order FROM $table_name
                WHERE template_id = %d
                ORDER BY rule_order ASC",
                $template_id
            )
        );

        $result = [];
        foreach ($rules as $rule) {
            $result[] = [
                'type' => $rule->rule_type,
                'config' => $rule->rule_config ? json_decode($rule->rule_config, true) : null,
                'order' => $rule->rule_order
            ];
        }

        // Cache the result
        $cache_manager->set($cache_key, $result, $cache_ttl);

        return $result;
    }

    /**
     * Get transformation variables for a template using normalized structure
     */
    public static function get_transformation_variables($template_id) {
        global $wpdb;

        $cache_manager = new CacheManager();
        $cache_key = 'transformation_variables_' . $template_id;
        $cache_ttl = 3600; // 1 hour cache

        // Try to get cached variables
        $cached_variables = $cache_manager->get($cache_key);
        if ($cached_variables !== false) {
            return $cached_variables;
        }

        $table_name = $wpdb->prefix . 'smo_transformation_variables';
        $variables = $wpdb->get_results(
            $wpdb->prepare(
                "SELECT variable_name, variable_type, default_value, description FROM $table_name
                WHERE template_id = %d
                ORDER BY variable_name ASC",
                $template_id
            )
        );

        $result = [];
        foreach ($variables as $variable) {
            $result[$variable->variable_name] = [
                'type' => $variable->variable_type,
                'default' => $variable->default_value,
                'description' => $variable->description
            ];
        }

        // Cache the result
        $cache_manager->set($cache_key, $result, $cache_ttl);

        return $result;
    }

    /**
     * Clear database-related caches
     */
    public static function clear_database_caches() {
        $cache_manager = new CacheManager();

        // Clear specific cache keys
        $cache_manager->delete('database_status_cache');

        // Clear table size caches
        $cache_manager->delete('table_size_*');

        // Clear batched table status caches
        $cache_manager->delete('batched_table_status_*');
        $cache_manager->delete('multiple_table_sizes_*');

        // Clear normalized data caches
        $cache_manager->delete('entity_platforms_*');
        $cache_manager->delete('post_media_*');
        $cache_manager->delete('transformation_rules_*');
        $cache_manager->delete('transformation_variables_*');

        return true;
    }
}
