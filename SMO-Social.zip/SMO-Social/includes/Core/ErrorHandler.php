<?php
namespace SMO_Social\Core;

class ErrorHandler {
    private $error_log;
    private $debug_mode;
    
    public function __construct($debug_mode = false) {
        $this->error_log = array();
        $this->debug_mode = $debug_mode;
        
        // Set up error handling
        set_error_handler(array($this, 'handle_error'));
        set_exception_handler(array($this, 'handle_exception'));
    }
    
    public function handle_error($severity, $message, $file, $line): bool {
        // Enhanced error context
        $error_context = [
            'severity' => $severity,
            'message' => $message,
            'file' => $file,
            'line' => $line,
            'memory_usage' => memory_get_usage(true),
            'peak_memory' => memory_get_peak_usage(true),
            'backtrace' => debug_backtrace(DEBUG_BACKTRACE_IGNORE_ARGS, 5),
            'timestamp' => current_time('mysql'),
            'user_id' => get_current_user_id(),
            'request_uri' => $_SERVER['REQUEST_URI'] ?? 'unknown',
            'request_method' => $_SERVER['REQUEST_METHOD'] ?? 'unknown',
            'user_agent' => $_SERVER['HTTP_USER_AGENT'] ?? 'unknown',
            'ip_address' => $this->get_client_ip() ?? 'unknown'
        ];
        
        $error = [
            'type' => $this->get_error_type($severity),
            'message' => $message,
            'file' => $file,
            'line' => $line,
            'timestamp' => current_time('mysql'),
            'severity' => $severity,
            'context' => $error_context
        ];
        
        $this->log_error($error);
        
        // Enhanced debugging with context
        if ($this->debug_mode && defined('WP_DEBUG') && WP_DEBUG) {
            error_log(sprintf(
                "SMO-Social Error [%s]: %s in %s:%d (Memory: %s, Peak: %s)",
                $this->get_error_type($severity),
                $message,
                $file,
                $line,
                $this->format_bytes(memory_get_usage(true)),
                $this->format_bytes(memory_get_peak_usage(true))
            ));
            
            // Log backtrace in debug mode
            if (!empty($error_context['backtrace'])) {
                error_log("SMO-Social Backtrace:");
                foreach ($error_context['backtrace'] as $index => $trace) {
                    $file = $trace['file'] ?? 'unknown';
                    $line = $trace['line'] ?? 'unknown';
                    $function = $trace['function'] ?? 'unknown';
                    error_log(sprintf("  [%d] %s:%d - %s", $index, $file, $line, $function));
                }
            }
        }
        
        return true; // Prevent default error handler
    }
    
    public function handle_exception($exception) {
        $error = array(
            'type' => 'Exception',
            'message' => $exception->getMessage(),
            'file' => $exception->getFile(),
            'line' => $exception->getLine(),
            'timestamp' => current_time('mysql'),
            'trace' => $exception->getTraceAsString()
        );
        
        $this->log_error($error);
        
        if ($this->debug_mode) {
            error_log("SMO-Social Exception: " . $exception->getMessage());
        }
    }
    
    public function log_error($error) {
        $this->error_log[] = $error;
        
        // Store in database if available
        if (function_exists('is_plugin_active')) {
            global $wpdb;
            if ($wpdb) {
                $table_name = $wpdb->prefix . 'smo_error_logs';
                $wpdb->insert($table_name, array(
                    'error_type' => $error['type'],
                    'message' => $error['message'],
                    'file' => $error['file'],
                    'line' => $error['line'],
                    'timestamp' => $error['timestamp']
                ));
            }
        }
    }
    
    public function get_errors() {
        return $this->error_log;
    }
    
    public function clear_errors() {
        $this->error_log = array();
    }
    
    public function get_error_type($severity) {
        $error_types = array(
            E_ERROR => 'Error',
            E_WARNING => 'Warning',
            E_PARSE => 'Parse Error',
            E_NOTICE => 'Notice',
            E_CORE_ERROR => 'Core Error',
            E_CORE_WARNING => 'Core Warning',
            E_COMPILE_ERROR => 'Compile Error',
            E_COMPILE_WARNING => 'Compile Warning',
            E_USER_ERROR => 'User Error',
            E_USER_WARNING => 'User Warning',
            E_USER_NOTICE => 'User Notice',
            E_STRICT => 'Strict Standards',
            E_RECOVERABLE_ERROR => 'Recoverable Error',
            E_DEPRECATED => 'Deprecated',
            E_USER_DEPRECATED => 'User Deprecated'
        );
        
        return $error_types[$severity] ?? 'Unknown Error';
    }
    
    public function report_error($message, $context = array()) {
        $error = array(
            'type' => 'Reported Error',
            'message' => $message,
            'context' => $context,
            'timestamp' => current_time('mysql')
        );
        
        $this->log_error($error);
        
        return array(
            'success' => true,
            'error_id' => count($this->error_log) - 1
        );
    }
    
    public function is_debug_mode() {
        return $this->debug_mode;
    }
    
    public function set_debug_mode($debug_mode) {
        $this->debug_mode = $debug_mode;
    }
    
    private function get_client_ip(): string {
        $ip_keys = ['HTTP_CLIENT_IP', 'HTTP_X_FORWARDED_FOR', 'HTTP_X_FORWARDED', 'HTTP_X_REAL_IP', 'HTTP_CF_CONNECTING_IP', 'REMOTE_ADDR'];
        
        foreach ($ip_keys as $key) {
            if (!empty($_SERVER[$key])) {
                $ips = explode(',', $_SERVER[$key]);
                $ip = trim($ips[0]);
                if (filter_var($ip, FILTER_VALIDATE_IP, FILTER_FLAG_NO_PRIV_RANGE | FILTER_FLAG_NO_RES_RANGE)) {
                    return $ip;
                }
            }
        }
        
        return $_SERVER['REMOTE_ADDR'] ?? 'unknown';
    }
    
    private function format_bytes(int $bytes): string {
        $units = ['B', 'KB', 'MB', 'GB', 'TB'];
        $unit_index = 0;
        
        while ($bytes >= 1024 && $unit_index < count($units) - 1) {
            $bytes /= 1024;
            $unit_index++;
        }
        
        return round($bytes, 2) . ' ' . $units[$unit_index];
    }
}
