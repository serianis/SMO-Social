<?php
namespace SMO_Social\Platforms;

class Facebook extends Platform {
    public function __construct($config = array()) {
        $default_config = array(
            'slug' => 'facebook',
            'name' => 'Facebook',
            'api_base' => 'https://graph.facebook.com/v18.0',
            'auth_type' => 'oauth',
            'max_chars' => 63206,
            'supports_images' => true,
            'supports_videos' => true,
            'rate_limit' => 200,
            'features' => array('posts', 'stories', 'reels', 'live_video')
        );

        $config = array_merge($default_config, $config);
        parent::__construct($config);
    }

    public function is_authenticated() {
        $token_data = $this->get_stored_token();
        return $token_data !== null;
    }

    public function create_post($data) {
        if (isset($data['test_mode']) && $data['test_mode']) {
            // In test mode, return mock response
            return array('id' => 'test_post_' . time());
        }
        return $this->post($data['message'], $data);
    }

    public function upload_media($data) {
        if (isset($data['test_mode']) && $data['test_mode']) {
            // In test mode, return mock response
            return array('media_id' => 'test_media_' . time());
        }
        // Implementation for media upload
        return array('success' => false, 'error' => 'Not implemented');
    }

    public function get_insights($data) {
        // For testing purposes, return mock data
        return array('impressions' => 100, 'reach' => 80, 'engagement' => 20);
    }

    public function get_comments($post_id) {
        // For testing purposes, return mock data
        return array(array('id' => 'comment_1', 'message' => 'Test comment'));
    }

    public function get_page_access_tokens() {
        // Implementation for getting page access tokens
        return array();
    }

    public function post_to_page($page_id, $content, $options = array()) {
        // Implementation for posting to a specific page
        return array('success' => false, 'error' => 'Not implemented');
    }

    public function get_pages() {
        // Implementation for getting connected pages
        return array();
    }
}
