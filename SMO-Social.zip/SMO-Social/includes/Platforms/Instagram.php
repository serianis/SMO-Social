<?php
namespace SMO_Social\Platforms;

class Instagram extends Platform {
    public function __construct($config = array()) {
        $default_config = array(
            'slug' => 'instagram',
            'name' => 'Instagram',
            'api_base' => 'https://graph.instagram.com/v18.0',
            'auth_type' => 'oauth',
            'max_chars' => 2200,
            'supports_images' => true,
            'supports_videos' => true,
            'rate_limit' => 200,
            'features' => array('posts', 'stories', 'reels', 'igtv')
        );

        $config = array_merge($default_config, $config);
        parent::__construct($config);
    }

    public function is_authenticated() {
        $token_data = $this->get_stored_token();
        return $token_data !== null;
    }

    public function create_media($data) {
        if (isset($data['test_mode']) && $data['test_mode']) {
            // In test mode, return mock response
            return array('id' => 'test_media_' . time());
        }
        return $this->post($data['caption'], $data);
    }

    public function get_insights($data) {
        // For testing purposes, return mock data
        return array(
            'impressions' => array('value' => 100),
            'reach' => array('value' => 80),
            'engagement' => array('value' => 20)
        );
    }

    public function get_media_insights($media_id) {
        // Implementation for getting media insights
        return array();
    }

    public function post_reel($content, $options = array()) {
        // Implementation for posting reels
        return array('success' => false, 'error' => 'Not implemented');
    }

    public function get_user_insights() {
        // Implementation for getting user insights
        return array();
    }
}
