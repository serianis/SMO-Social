<?php
namespace SMO_Social\Platforms;

class Twitter extends Platform {
    public function __construct($config = array()) {
        $default_config = array(
            'slug' => 'twitter',
            'name' => 'Twitter/X',
            'api_base' => 'https://api.twitter.com/2',
            'auth_type' => 'oauth',
            'max_chars' => 280,
            'supports_images' => true,
            'supports_videos' => true,
            'rate_limit' => 300,
            'features' => array('tweets', 'threads', 'spaces', 'polls')
        );

        $config = array_merge($default_config, $config);
        parent::__construct($config);
    }

    public function is_authenticated() {
        $token_data = $this->get_stored_token();
        return $token_data !== null;
    }

    public function create_tweet($data) {
        if (isset($data['test_mode']) && $data['test_mode']) {
            // In test mode, return mock response
            return array('data' => array('id' => 'test_tweet_' . time()));
        }
        return $this->post($data['text'], $data);
    }

    public function upload_media($data) {
        if (isset($data['test_mode']) && $data['test_mode']) {
            // In test mode, return mock response
            return array('media_id_string' => 'test_media_' . time());
        }
        // Implementation for media upload
        return array('success' => false, 'error' => 'Not implemented');
    }

    public function get_tweet_metrics($tweet_id) {
        // For testing purposes, return mock data
        return array(
            'retweet_count' => 10,
            'like_count' => 25,
            'reply_count' => 5,
            'impression_count' => 1000
        );
    }

    public function post_thread($tweets, $options = array()) {
        // Implementation for posting thread
        return array('success' => false, 'error' => 'Not implemented');
    }

    public function get_mentions() {
        // Implementation for getting mentions
        return array();
    }

    public function get_trending_topics() {
        // Implementation for getting trending topics
        return array();
    }
}
