<?php
/**
 * SMO Social HuggingFace Configuration
 * Generated automatically
 */

if (!defined('ABSPATH')) {
    // Standalone mode configuration
    if (!function_exists('get_option')) {
        function get_option($option_name, $default = false) {
            static $options = [];
            if (empty($options)) {
                // Load from file if exists
                $config_file = __DIR__ . '/.smo-social-config.php';
                if (file_exists($config_file)) {
                    $options = include $config_file;
                }
            }
            return $options[$option_name] ?? $default;
        }
    }
    
    if (!function_exists('update_option')) {
        function update_option($option_name, $value) {
            $config_file = __DIR__ . '/.smo-social-config.php';
            $options = [];
            
            // Load existing options
            if (file_exists($config_file)) {
                $options = include $config_file;
            }
            
            // Update the option
            $options[$option_name] = $value;
            
            // Save back to file
            $content = "<?php
return " . var_export($options, true) . ";
";
            return file_put_contents($config_file, $content) !== false;
        }
    }
}

// Set the HuggingFace API key
echo "🔧 Setting HuggingFace API key...
";

// Try to set using WordPress functions first
if (function_exists('update_option')) {
    $result = update_option('smo_social_huggingface_api_key', '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');
} else {
    // Use our simple configuration system
    $result = update_option('smo_social_huggingface_api_key', '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');
}

if ($result) {
    echo "✅ Successfully set HuggingFace API key!
";
    echo "API Key: " . substr('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', 0, 8) . "..." . substr('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', -8) . "
";
    
    // Verify it was saved correctly
    $saved_key = get_option('smo_social_huggingface_api_key', '');
    if ($saved_key === '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') {
        echo "✅ Verification: API key saved correctly
";
    } else {
        echo "❌ Verification: API key may not have been saved correctly
";
        echo "Expected: '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'
";
        echo "Got: '$saved_key'
";
    }
    
    echo "
🚀 The HuggingFace API key has been successfully configured!
";
    echo "You can now use the AI chat functionality.
";
    
} else {
    echo "❌ Failed to set HuggingFace API key
";
}

echo "
📋 Next Steps:
";
echo "1. The API key is now configured in the system
";
echo "2. Test the AI chat functionality
";
echo "3. If using WordPress, the key will be available in the admin panel
";
echo "4. If using standalone mode, the key is stored in .smo-social-config.php
";