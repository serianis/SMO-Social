<?php
echo "Simple test file loaded\n";
?>