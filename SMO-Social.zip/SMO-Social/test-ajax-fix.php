<?php
/**
 * Test script to verify AJAX configuration fix
 * This script simulates the WordPress environment and tests if the AssetManager properly localizes the script
 */

// Mock WordPress environment for testing
define('ABSPATH', '/tmp/');
define('WPINC', 'wp-includes');

// Mock WordPress functions
if (!function_exists('wp_enqueue_script')) {
    function wp_enqueue_script($handle, $src = '', $deps = array(), $ver = false, $in_footer = false) {
        echo "wp_enqueue_script: $handle\n";
        return true;
    }
}

if (!function_exists('wp_enqueue_style')) {
    function wp_enqueue_style($handle, $src = '', $deps = array(), $ver = false, $media = 'all') {
        echo "wp_enqueue_style: $handle\n";
        return true;
    }
}

if (!function_exists('wp_localize_script')) {
    function wp_localize_script($handle, $object_name, $l10n) {
        echo "wp_localize_script: $handle -> $object_name\n";
        echo "Data: " . print_r($l10n, true) . "\n";
        return true;
    }
}

if (!function_exists('admin_url')) {
    function admin_url($path = '', $scheme = 'admin') {
        return 'http://localhost/wp-admin/' . $path;
    }
}

if (!function_exists('wp_create_nonce')) {
    function wp_create_nonce($action) {
        return 'test_nonce_' . $action;
    }
}

if (!function_exists('__')) {
    function __($text, $domain = 'default') {
        return $text;
    }
}

if (!function_exists('add_action')) {
    function add_action($hook, $function_to_add, $priority = 10, $accepted_args = 1) {
        echo "add_action: $hook\n";
        return true;
    }
}

// Mock WordPress globals
$GLOBALS['wp'] = new stdClass();
$GLOBALS['wp']->query_vars = array();

// Mock SMO Social environment
define('SMO_SOCIAL_VERSION', '1.0.0');

// Mock EnvironmentDetector class
namespace SMO_Social\Utilities {
    class EnvironmentDetector {
        public static function isWordPress() {
            return true;
        }
    }
}

// Mock Logger class
namespace SMO_Social\Core {
    class Logger {
        public static function debug($message) {
            echo "DEBUG: $message\n";
        }
        
        public static function error($message) {
            echo "ERROR: $message\n";
        }
    }
}

// Load the AssetManager class
require_once 'includes/Admin/AssetManager.php';

echo "=== Testing AssetManager AJAX Configuration Fix ===\n\n";

// Create a mock integration manager
class MockIntegrationManager {
    public function get_all_integrations() {
        return array();
    }
}

// Initialize AssetManager
$plugin_url = 'http://localhost/wp-content/plugins/smo-social/';
$integration_manager = new MockIntegrationManager();

echo "Initializing AssetManager...\n";
$asset_manager = new \SMO_Social\Admin\AssetManager($plugin_url, $integration_manager);

echo "\nTesting enqueue_assets method...\n";
echo "Simulating admin page hook: 'toplevel_page_smo-social'\n";

// Call the enqueue_assets method directly
$asset_manager->enqueue_assets('toplevel_page_smo-social');

echo "\n=== Test Complete ===\n";
echo "If you see 'wp_localize_script: smo-social-admin -> smo_social_ajax' above,\n";
echo "then the fix is working correctly and the AJAX configuration is being localized.\n";