/**
 * Comprehensive Dashboard Fixes Test Suite
 * Tests all the fixes implemented in the dashboard redesign
 */

// Mock jQuery and DOM environment for testing
const { JSDOM } = require('jsdom');
const dom = new JSDOM('<!DOCTYPE html><html><body></body></html>');
global.window = dom.window;
global.document = dom.window.document;
global.$ = global.jQuery = require('jquery')(dom.window);

// Mock console methods for testing
const consoleOutput = [];
const originalConsole = {
    log: console.log,
    warn: console.warn,
    error: console.error
};

console.log = (...args) => {
    consoleOutput.push({ type: 'log', args });
    originalConsole.log(...args);
};

console.warn = (...args) => {
    consoleOutput.push({ type: 'warn', args });
    originalConsole.warn(...args);
};

console.error = (...args) => {
    consoleOutput.push({ type: 'error', args });
    originalConsole.error(...args);
};

// Mock AJAX and WordPress globals
global.smo_dashboard_ajax = {
    ajax_url: 'https://example.com/wp-admin/admin-ajax.php',
    create_post_url: 'https://example.com/wp-admin/post-new.php',
    nonce: 'test_nonce_123'
};

// Test results storage
const testResults = {
    passed: 0,
    failed: 0,
    warnings: 0,
    tests: []
};

// Test utilities
function startTest(name) {
    console.log(`\n=== TEST: ${name} ===`);
    return {
        name,
        startTime: Date.now(),
        log: (message) => console.log(`[LOG] ${message}`),
        warn: (message) => console.warn(`[WARN] ${message}`),
        error: (message) => console.error(`[ERROR] ${message}`),
        assert: (condition, message) => {
            if (!condition) {
                throw new Error(`Assertion failed: ${message}`);
            }
        }
    };
}

function endTest(test, status = 'passed', details = '') {
    const endTime = Date.now();
    const duration = endTime - test.startTime;

    testResults.tests.push({
        name: test.name,
        status,
        duration: `${duration}ms`,
        details
    });

    if (status === 'passed') testResults.passed++;
    else if (status === 'failed') testResults.failed++;
    else if (status === 'warning') testResults.warnings++;

    console.log(`=== RESULT: ${status.toUpperCase()} (${duration}ms) ===`);
    if (details) console.log(`Details: ${details}`);
}

// Import the dashboard code
const dashboardCode = require('./assets/js/dashboard-redesign.js');

// Test Suite 1: URL Validation Logic
function testURLValidation() {
    const test = startTest('URL Validation Logic');

    try {
        // Test 1: Valid URL should pass
        const validUrl = 'https://example.com';
        const result1 = dashboardCode.validateUrl(validUrl);
        test.assert(result1 === true, 'Valid URL should be accepted');

        // Test 2: Malicious URL should be blocked
        const maliciousUrl = 'javascript:alert("xss")';
        const result2 = dashboardCode.validateUrl(maliciousUrl);
        test.assert(result2 === false, 'Malicious URL should be blocked');

        // Test 3: URL with HTML injection should be blocked
        const htmlInjectionUrl = 'https://example.com/%3Cdiv%20class=test';
        const result3 = dashboardCode.validateUrl(htmlInjectionUrl);
        test.assert(result3 === false, 'URL with HTML injection should be blocked');

        endTest(test, 'passed', 'All URL validation tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 2: Navigation Logic with WordPress Admin Links
function testNavigationLogic() {
    const test = startTest('Navigation Logic with WordPress Admin Links');

    try {
        // Setup DOM for navigation test
        document.body.innerHTML = `
            <div class="smo-nav-item" href="https://example.com/wp-admin" data-view="dashboard">Dashboard</div>
            <div class="smo-nav-item" href="#" data-view="settings">Settings</div>
            <div class="smo-nav-item" data-view="analytics">Analytics</div>
        `;

        // Test WordPress admin link navigation (should not prevent default)
        const wpAdminLink = document.querySelector('[href="https://example.com/wp-admin"]');
        const event1 = new MouseEvent('click', { bubbles: true });
        let defaultPrevented1 = false;
        event1.preventDefault = () => { defaultPrevented1 = true; };

        wpAdminLink.dispatchEvent(event1);
        test.assert(!defaultPrevented1, 'WordPress admin links should not prevent default');

        // Test SPA navigation (should prevent default)
        const spaLink = document.querySelector('[data-view="analytics"]');
        const event2 = new MouseEvent('click', { bubbles: true });
        let defaultPrevented2 = false;
        event2.preventDefault = () => { defaultPrevented2 = true; };

        spaLink.dispatchEvent(event2);
        test.assert(defaultPrevented2, 'SPA navigation should prevent default');

        endTest(test, 'passed', 'Navigation logic tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 3: Template Sanitization
function testTemplateSanitization() {
    const test = startTest('Improved sanitizeTemplateForUrl function');

    try {
        // Test malicious template data
        const maliciousTemplate = {
            name: '<script>alert("xss")</script>',
            content: '<div class="malicious">Test</div>',
            description: 'Test & <script>alert(1)</script>'
        };

        const sanitized = dashboardCode.sanitizeTemplateForUrl(maliciousTemplate);

        test.assert(!sanitized.name.includes('<script>'), 'Script tags should be removed from name');
        test.assert(!sanitized.content.includes('<div'), 'HTML tags should be removed from content');
        test.assert(sanitized.description.includes('&'), 'Ampersands should be encoded');

        endTest(test, 'passed', 'Template sanitization tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 4: Memory Leak Prevention
function testMemoryLeakPrevention() {
    const test = startTest('Memory Leak Prevention for Event Listeners');

    try {
        // Test event listener cleanup
        const cleanupCount = dashboardCode.cleanupTemplatePopups();
        test.assert(cleanupCount >= 0, 'Cleanup function should return count of removed elements');

        // Test that event listeners are properly removed
        const eventListenersBefore = document.querySelectorAll('.smo-template-preview-popup').length;
        dashboardCode.cleanupTemplatePopups();
        const eventListenersAfter = document.querySelectorAll('.smo-template-preview-popup').length;

        test.assert(eventListenersAfter === 0, 'All template popups should be removed');
        test.assert(eventListenersAfter < eventListenersBefore, 'Cleanup should reduce element count');

        endTest(test, 'passed', 'Memory leak prevention tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 5: Accessibility Attributes
function testAccessibility() {
    const test = startTest('Accessibility Attributes');

    try {
        // Test that error notifications have proper ARIA attributes
        const errorNotification = dashboardCode.showErrorNotification('Test error');
        test.assert(errorNotification.hasAttribute('role'), 'Error notification should have role attribute');
        test.assert(errorNotification.getAttribute('role') === 'alert', 'Error notification should have alert role');
        test.assert(errorNotification.hasAttribute('aria-live'), 'Error notification should have aria-live');

        // Test template popup accessibility
        const templatePopup = document.createElement('div');
        templatePopup.className = 'smo-template-preview-popup';
        templatePopup.setAttribute('role', 'dialog');
        templatePopup.setAttribute('aria-labelledby', 'template-preview-title');
        templatePopup.setAttribute('aria-modal', 'true');

        document.body.appendChild(templatePopup);

        test.assert(templatePopup.hasAttribute('role'), 'Template popup should have role attribute');
        test.assert(templatePopup.getAttribute('role') === 'dialog', 'Template popup should have dialog role');

        endTest(test, 'passed', 'Accessibility tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 6: Dark Mode Toggle with AJAX Fallback
function testDarkModeToggle() {
    const test = startTest('Dark Mode Toggle with AJAX Fallback');

    try {
        // Mock AJAX failure
        const originalAjax = $.ajax;
        $.ajax = () => ({
            fail: (callback) => callback({ responseText: 'AJAX failed' }),
            always: (callback) => callback()
        });

        // Test dark mode toggle
        const body = document.body;
        const initialDarkMode = body.classList.contains('smo-dark-mode');

        dashboardCode.toggleDarkMode();

        // Should toggle immediately even if AJAX fails
        const afterToggleDarkMode = body.classList.contains('smo-dark-mode');
        test.assert(afterToggleDarkMode !== initialDarkMode, 'Dark mode should toggle immediately');

        // Restore AJAX
        $.ajax = originalAjax;

        endTest(test, 'passed', 'Dark mode toggle tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 7: Loading States for Async Operations
function testLoadingStates() {
    const test = startTest('Loading States for Async Operations');

    try {
        // Test loading state during navigation
        const body = document.body;
        const initialLoadingState = body.classList.contains('smo-loading');

        // Simulate navigation start
        dashboardCode.startNavigation();
        const duringLoadingState = body.classList.contains('smo-loading');
        test.assert(duringLoadingState, 'Loading state should be active during navigation');

        // Simulate navigation end
        dashboardCode.endNavigation();
        const afterLoadingState = body.classList.contains('smo-loading');
        test.assert(!afterLoadingState, 'Loading state should be removed after navigation');

        endTest(test, 'passed', 'Loading state tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 8: Visual Layout Responsiveness
function testVisualLayout() {
    const test = startTest('Visual Layout across Different Screen Sizes');

    try {
        // Test desktop layout
        global.innerWidth = 1200;
        global.dispatchEvent(new Event('resize'));

        const desktopLayout = document.querySelector('.smo-dashboard-wrapper');
        test.assert(getComputedStyle(desktopLayout).flexDirection === 'row', 'Desktop should use row layout');

        // Test tablet layout
        global.innerWidth = 768;
        global.dispatchEvent(new Event('resize'));

        const tabletLayout = document.querySelector('.smo-dashboard-wrapper');
        test.assert(getComputedStyle(tabletLayout).flexDirection === 'column', 'Tablet should use column layout');

        // Test mobile layout
        global.innerWidth = 480;
        global.dispatchEvent(new Event('resize'));

        const mobileLayout = document.querySelector('.smo-dashboard-wrapper');
        test.assert(getComputedStyle(mobileLayout).flexDirection === 'column', 'Mobile should use column layout');

        endTest(test, 'passed', 'Visual layout responsiveness tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Test Suite 9: Error Handling and Cleanup
function testErrorHandling() {
    const test = startTest('Error Handling and Cleanup for Template Operations');

    try {
        // Test error handling in template operations
        const errorThrown = false;
        try {
            dashboardCode.handleTemplateError(new Error('Test error'));
        } catch (e) {
            errorThrown = true;
        }

        test.assert(!errorThrown, 'Template errors should be handled gracefully');

        // Test cleanup of dynamically created elements
        const initialElements = document.querySelectorAll('.smo-dynamic-element').length;
        dashboardCode.cleanupDynamicElements();
        const afterCleanupElements = document.querySelectorAll('.smo-dynamic-element').length;

        test.assert(afterCleanupElements === 0, 'All dynamic elements should be cleaned up');

        endTest(test, 'passed', 'Error handling and cleanup tests passed');
    } catch (error) {
        endTest(test, 'failed', error.message);
    }
}

// Run all tests
function runAllTests() {
    console.log('=== COMPREHENSIVE DASHBOARD FIXES TEST SUITE ===');
    console.log('Starting tests...');

    testURLValidation();
    testNavigationLogic();
    testTemplateSanitization();
    testMemoryLeakPrevention();
    testAccessibility();
    testDarkModeToggle();
    testLoadingStates();
    testVisualLayout();
    testErrorHandling();

    // Generate test report
    console.log('\n=== TEST SUMMARY ===');
    console.log(`Total Tests: ${testResults.tests.length}`);
    console.log(`Passed: ${testResults.passed}`);
    console.log(`Failed: ${testResults.failed}`);
    console.log(`Warnings: ${testResults.warnings}`);

    // Detailed results
    console.log('\n=== DETAILED RESULTS ===');
    testResults.tests.forEach(test => {
        console.log(`${test.status.toUpperCase()}: ${test.name} (${test.duration})`);
        if (test.details) console.log(`  ${test.details}`);
    });

    // Generate HTML report
    generateHTMLReport();
}

function generateHTMLReport() {
    const reportDate = new Date().toISOString();
    const htmlReport = `
<!DOCTYPE html>
<html>
<head>
    <title>Dashboard Fixes Test Report</title>
    <style>
        body { font-family: Arial, sans-serif; margin: 20px; }
        h1 { color: #333; }
        .summary { background: #f5f5f5; padding: 15px; margin-bottom: 20px; border-radius: 5px; }
        .test-result { margin-bottom: 10px; padding: 10px; border-radius: 3px; }
        .passed { background: #e6ffe6; border-left: 4px solid #4CAF50; }
        .failed { background: #ffebee; border-left: 4px solid #f44336; }
        .warning { background: #fff8e1; border-left: 4px solid #ffc107; }
        .details { font-size: 12px; color: #666; margin-top: 5px; }
    </style>
</head>
<body>
    <h1>Dashboard Fixes Test Report</h1>
    <div class="summary">
        <h2>Test Summary</h2>
        <p><strong>Date:</strong> ${reportDate}</p>
        <p><strong>Total Tests:</strong> ${testResults.tests.length}</p>
        <p><strong>Passed:</strong> ${testResults.passed}</p>
        <p><strong>Failed:</strong> ${testResults.failed}</p>
        <p><strong>Warnings:</strong> ${testResults.warnings}</p>
    </div>

    <h2>Detailed Results</h2>
    ${testResults.tests.map(test => `
        <div class="test-result ${test.status}">
            <strong>${test.name}</strong> - ${test.status.toUpperCase()}
            <div class="details">${test.duration} | ${test.details || 'No additional details'}</div>
        </div>
    `).join('')}

    <h2>Console Output</h2>
    <pre>${consoleOutput.map(item => `[${item.type.toUpperCase()}] ${item.args.join(' ')}`).join('\n')}</pre>
</body>
</html>
    `;

    require('fs').writeFileSync('DASHBOARD_FIXES_TEST_REPORT.html', htmlReport);
    console.log('HTML test report generated: DASHBOARD_FIXES_TEST_REPORT.html');
}

// Run tests when script is executed
if (require.main === module) {
    runAllTests();
}

module.exports = {
    runAllTests,
    testResults
};