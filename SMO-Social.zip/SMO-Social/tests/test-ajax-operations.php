<?php
/**
 * Comprehensive AJAX Operations Test for Content Organizer
 *
 * This test file verifies all AJAX operations for the Content Organizer feature
 * including backend responses, error handling, and data validation.
 */

// Set up test environment
define('SMO_SOCIAL_TESTING', true);
require_once 'includes/Admin/Admin.php';
require_once 'includes/Database/DatabaseSchema.php';

// Mock WordPress environment for testing
if (!function_exists('wp_send_json_success')) {
    function wp_send_json_success($data) {
        echo json_encode(array('success' => true, 'data' => $data));
        exit;
    }
}

if (!function_exists('wp_send_json_error')) {
    function wp_send_json_error($message) {
        echo json_encode(array('success' => false, 'error' => $message));
        exit;
    }
}

if (!function_exists('check_ajax_referer')) {
    function check_ajax_referer($action, $nonce) {
        // Mock nonce verification for testing
        return true;
    }
}

if (!function_exists('current_user_can')) {
    function current_user_can($capability) {
        // Mock user capability check
        return true;
    }
}

// Test AJAX Operations
class ContentOrganizerAJAXTest {
    private $admin;
    private $test_results = array();

    public function __construct() {
        $this->admin = new SMO_Social\Admin\Admin();
        echo "Starting Content Organizer AJAX Operations Test...\n";
    }

    public function run_all_tests() {
        $this->test_get_organizer_stats();
        $this->test_get_rss_feeds();
        $this->test_add_rss_feed();
        $this->test_get_imported_content();
        $this->test_save_category();
        $this->test_get_categories();
        $this->test_delete_category();
        $this->test_save_quick_idea();
        $this->test_save_idea();
        $this->test_get_ideas();
        $this->test_update_idea_status();
        $this->test_delete_idea();

        $this->generate_test_report();
    }

    private function test_get_organizer_stats() {
        echo "\n=== Testing ajax_get_organizer_stats ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_get_organizer_stats();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['get_organizer_stats'] = 'PASS';
                echo "✓ ajax_get_organizer_stats: PASS\n";
            } else {
                $this->test_results['get_organizer_stats'] = 'FAIL';
                echo "✗ ajax_get_organizer_stats: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['get_organizer_stats'] = 'ERROR';
            echo "✗ ajax_get_organizer_stats: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_get_rss_feeds() {
        echo "\n=== Testing ajax_get_rss_feeds ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_get_rss_feeds();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['get_rss_feeds'] = 'PASS';
                echo "✓ ajax_get_rss_feeds: PASS\n";
            } else {
                $this->test_results['get_rss_feeds'] = 'FAIL';
                echo "✗ ajax_get_rss_feeds: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['get_rss_feeds'] = 'ERROR';
            echo "✗ ajax_get_rss_feeds: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_add_rss_feed() {
        echo "\n=== Testing ajax_add_rss_feed ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';
        $_POST['url'] = 'https://example.com/rss-feed';
        $_POST['name'] = 'Test RSS Feed';
        $_POST['auto_import'] = true;

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_add_rss_feed();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['add_rss_feed'] = 'PASS';
                echo "✓ ajax_add_rss_feed: PASS\n";
            } else {
                $this->test_results['add_rss_feed'] = 'FAIL';
                echo "✗ ajax_add_rss_feed: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['add_rss_feed'] = 'ERROR';
            echo "✗ ajax_add_rss_feed: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_get_imported_content() {
        echo "\n=== Testing ajax_get_imported_content ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';
        $_POST['limit'] = 10;

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_get_imported_content();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['get_imported_content'] = 'PASS';
                echo "✓ ajax_get_imported_content: PASS\n";
            } else {
                $this->test_results['get_imported_content'] = 'FAIL';
                echo "✗ ajax_get_imported_content: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['get_imported_content'] = 'ERROR';
            echo "✗ ajax_get_imported_content: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_save_category() {
        echo "\n=== Testing ajax_save_category ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';
        $_POST['name'] = 'Test Category';
        $_POST['description'] = 'This is a test category';
        $_POST['color'] = '#667eea';
        $_POST['icon'] = '📁';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_save_category();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['save_category'] = 'PASS';
                echo "✓ ajax_save_category: PASS\n";
            } else {
                $this->test_results['save_category'] = 'FAIL';
                echo "✗ ajax_save_category: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['save_category'] = 'ERROR';
            echo "✗ ajax_save_category: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_get_categories() {
        echo "\n=== Testing ajax_get_categories ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_get_categories();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['get_categories'] = 'PASS';
                echo "✓ ajax_get_categories: PASS\n";
            } else {
                $this->test_results['get_categories'] = 'FAIL';
                echo "✗ ajax_get_categories: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['get_categories'] = 'ERROR';
            echo "✗ ajax_get_categories: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_delete_category() {
        echo "\n=== Testing ajax_delete_category ===\n";

        // First, create a category to delete
        $_POST['nonce'] = 'test_nonce';
        $_POST['name'] = 'Category to Delete';
        $_POST['description'] = 'This category will be deleted';
        $_POST['color'] = '#667eea';
        $_POST['icon'] = '📁';

        ob_start();
        $this->admin->ajax_save_category();
        $output = ob_get_clean();
        $result = json_decode($output, true);
        $category_id = $result['data']['id'] ?? 0;

        if ($category_id > 0) {
            // Now test deletion
            $_POST['id'] = $category_id;

            ob_start();
            try {
                $this->admin->ajax_delete_category();
                $output = ob_get_clean();

                $result = json_decode($output, true);
                if ($result && isset($result['success']) && $result['success']) {
                    $this->test_results['delete_category'] = 'PASS';
                    echo "✓ ajax_delete_category: PASS\n";
                } else {
                    $this->test_results['delete_category'] = 'FAIL';
                    echo "✗ ajax_delete_category: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
                }
            } catch (Exception $e) {
                $this->test_results['delete_category'] = 'ERROR';
                echo "✗ ajax_delete_category: ERROR - " . $e->getMessage() . "\n";
                ob_end_clean();
            }
        } else {
            $this->test_results['delete_category'] = 'SKIP';
            echo "✗ ajax_delete_category: SKIP - Could not create test category\n";
        }
    }

    private function test_save_quick_idea() {
        echo "\n=== Testing ajax_save_quick_idea ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';
        $_POST['title'] = 'Test Quick Idea';
        $_POST['description'] = 'This is a test quick idea';
        $_POST['category'] = 0;
        $_POST['priority'] = 'medium';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_save_quick_idea();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['save_quick_idea'] = 'PASS';
                echo "✓ ajax_save_quick_idea: PASS\n";
            } else {
                $this->test_results['save_quick_idea'] = 'FAIL';
                echo "✗ ajax_save_quick_idea: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['save_quick_idea'] = 'ERROR';
            echo "✗ ajax_save_quick_idea: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_save_idea() {
        echo "\n=== Testing ajax_save_idea ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';
        $_POST['title'] = 'Test Idea';
        $_POST['content'] = 'This is a test idea with detailed content';
        $_POST['category'] = 0;
        $_POST['priority'] = 'medium';
        $_POST['status'] = 'idea';
        $_POST['tags'] = 'test,idea';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_save_idea();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['save_idea'] = 'PASS';
                echo "✓ ajax_save_idea: PASS\n";
            } else {
                $this->test_results['save_idea'] = 'FAIL';
                echo "✗ ajax_save_idea: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['save_idea'] = 'ERROR';
            echo "✗ ajax_save_idea: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_get_ideas() {
        echo "\n=== Testing ajax_get_ideas ===\n";

        // Mock POST data
        $_POST['nonce'] = 'test_nonce';

        // Capture output
        ob_start();
        try {
            $this->admin->ajax_get_ideas();
            $output = ob_get_clean();

            $result = json_decode($output, true);
            if ($result && isset($result['success']) && $result['success']) {
                $this->test_results['get_ideas'] = 'PASS';
                echo "✓ ajax_get_ideas: PASS\n";
            } else {
                $this->test_results['get_ideas'] = 'FAIL';
                echo "✗ ajax_get_ideas: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
            }
        } catch (Exception $e) {
            $this->test_results['get_ideas'] = 'ERROR';
            echo "✗ ajax_get_ideas: ERROR - " . $e->getMessage() . "\n";
            ob_end_clean();
        }
    }

    private function test_update_idea_status() {
        echo "\n=== Testing ajax_update_idea_status ===\n";

        // First, create an idea to update
        $_POST['nonce'] = 'test_nonce';
        $_POST['title'] = 'Idea to Update';
        $_POST['content'] = 'This idea will have its status updated';
        $_POST['category'] = 0;
        $_POST['priority'] = 'medium';
        $_POST['status'] = 'idea';
        $_POST['tags'] = 'test,update';

        ob_start();
        $this->admin->ajax_save_idea();
        $output = ob_get_clean();
        $result = json_decode($output, true);
        $idea_id = $result['data']['id'] ?? 0;

        if ($idea_id > 0) {
            // Now test status update
            $_POST['idea_id'] = $idea_id;
            $_POST['status'] = 'draft';

            ob_start();
            try {
                $this->admin->ajax_update_idea_status();
                $output = ob_get_clean();

                $result = json_decode($output, true);
                if ($result && isset($result['success']) && $result['success']) {
                    $this->test_results['update_idea_status'] = 'PASS';
                    echo "✓ ajax_update_idea_status: PASS\n";
                } else {
                    $this->test_results['update_idea_status'] = 'FAIL';
                    echo "✗ ajax_update_idea_status: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
                }
            } catch (Exception $e) {
                $this->test_results['update_idea_status'] = 'ERROR';
                echo "✗ ajax_update_idea_status: ERROR - " . $e->getMessage() . "\n";
                ob_end_clean();
            }
        } else {
            $this->test_results['update_idea_status'] = 'SKIP';
            echo "✗ ajax_update_idea_status: SKIP - Could not create test idea\n";
        }
    }

    private function test_delete_idea() {
        echo "\n=== Testing ajax_delete_idea ===\n";

        // First, create an idea to delete
        $_POST['nonce'] = 'test_nonce';
        $_POST['title'] = 'Idea to Delete';
        $_POST['content'] = 'This idea will be deleted';
        $_POST['category'] = 0;
        $_POST['priority'] = 'medium';
        $_POST['status'] = 'idea';
        $_POST['tags'] = 'test,delete';

        ob_start();
        $this->admin->ajax_save_idea();
        $output = ob_get_clean();
        $result = json_decode($output, true);
        $idea_id = $result['data']['id'] ?? 0;

        if ($idea_id > 0) {
            // Now test deletion
            $_POST['id'] = $idea_id;

            ob_start();
            try {
                $this->admin->ajax_delete_idea();
                $output = ob_get_clean();

                $result = json_decode($output, true);
                if ($result && isset($result['success']) && $result['success']) {
                    $this->test_results['delete_idea'] = 'PASS';
                    echo "✓ ajax_delete_idea: PASS\n";
                } else {
                    $this->test_results['delete_idea'] = 'FAIL';
                    echo "✗ ajax_delete_idea: FAIL - " . ($result['error'] ?? 'Unknown error') . "\n";
                }
            } catch (Exception $e) {
                $this->test_results['delete_idea'] = 'ERROR';
                echo "✗ ajax_delete_idea: ERROR - " . $e->getMessage() . "\n";
                ob_end_clean();
            }
        } else {
            $this->test_results['delete_idea'] = 'SKIP';
            echo "✗ ajax_delete_idea: SKIP - Could not create test idea\n";
        }
    }

    private function generate_test_report() {
        echo "\n" . str_repeat("=", 50) . "\n";
        echo "CONTENT ORGANIZER AJAX OPERATIONS TEST REPORT\n";
        echo str_repeat("=", 50) . "\n";

        $pass_count = 0;
        $fail_count = 0;
        $error_count = 0;
        $skip_count = 0;

        foreach ($this->test_results as $test_name => $result) {
            echo str_pad($test_name, 30) . ": " . $result . "\n";

            switch ($result) {
                case 'PASS': $pass_count++; break;
                case 'FAIL': $fail_count++; break;
                case 'ERROR': $error_count++; break;
                case 'SKIP': $skip_count++; break;
            }
        }

        echo "\n" . str_repeat("-", 50) . "\n";
        echo "SUMMARY:\n";
        echo "Total Tests: " . count($this->test_results) . "\n";
        echo "Passed: " . $pass_count . "\n";
        echo "Failed: " . $fail_count . "\n";
        echo "Errors: " . $error_count . "\n";
        echo "Skipped: " . $skip_count . "\n";

        $success_rate = ($pass_count / count($this->test_results)) * 100;
        echo "Success Rate: " . round($success_rate, 1) . "%\n";

        if ($fail_count === 0 && $error_count === 0) {
            echo "\n🎉 ALL TESTS PASSED! Content Organizer AJAX operations are working correctly.\n";
        } else {
            echo "\n⚠️  Some tests failed. Please review the results above.\n";
        }

        echo str_repeat("=", 50) . "\n";
    }
}

// Run the tests
$test = new ContentOrganizerAJAXTest();
$test->run_all_tests();