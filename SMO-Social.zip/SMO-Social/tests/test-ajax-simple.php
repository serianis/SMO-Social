<?php
/**
 * Simple AJAX Operations Test for Content Organizer
 *
 * This test file verifies the basic AJAX operations structure and functionality
 * without requiring the full WordPress environment.
 */

echo "Starting Simple AJAX Operations Test...\n";

// Test 1: Verify AJAX handler methods exist
echo "\n=== Testing AJAX Handler Method Existence ===\n";

$admin_file = file_get_contents('includes/Admin/Admin.php');

$ajax_methods = [
    'ajax_get_organizer_stats',
    'ajax_get_rss_feeds',
    'ajax_add_rss_feed',
    'ajax_get_imported_content',
    'ajax_save_category',
    'ajax_get_categories',
    'ajax_delete_category',
    'ajax_save_quick_idea',
    'ajax_save_idea',
    'ajax_get_ideas',
    'ajax_update_idea_status',
    'ajax_delete_idea'
];

$found_methods = [];
$missing_methods = [];

foreach ($ajax_methods as $method) {
    if (strpos($admin_file, "public function $method") !== false) {
        $found_methods[] = $method;
        echo "✓ Found method: $method\n";
    } else {
        $missing_methods[] = $method;
        echo "✗ Missing method: $method\n";
    }
}

// Test 2: Verify AJAX action hooks are registered
echo "\n=== Testing AJAX Action Hook Registration ===\n";

$ajax_actions = [
    'wp_ajax_smo_get_organizer_stats',
    'wp_ajax_smo_get_rss_feeds',
    'wp_ajax_smo_add_rss_feed',
    'wp_ajax_smo_get_imported_content',
    'wp_ajax_smo_save_category',
    'wp_ajax_smo_get_categories',
    'wp_ajax_smo_delete_category',
    'wp_ajax_smo_save_quick_idea',
    'wp_ajax_smo_save_idea',
    'wp_ajax_smo_get_ideas',
    'wp_ajax_smo_update_idea_status',
    'wp_ajax_smo_delete_idea'
];

$found_actions = [];
$missing_actions = [];

foreach ($ajax_actions as $action) {
    if (strpos($admin_file, "add_action('$action'") !== false) {
        $found_actions[] = $action;
        echo "✓ Found action: $action\n";
    } else {
        $missing_actions[] = $action;
        echo "✗ Missing action: $action\n";
    }
}

// Test 3: Verify method signatures and parameters
echo "\n=== Testing Method Signatures ===\n";

$method_tests = [
    'ajax_get_organizer_stats' => ['nonce' => true],
    'ajax_get_rss_feeds' => ['nonce' => true],
    'ajax_add_rss_feed' => ['nonce' => true, 'url' => true, 'name' => true, 'auto_import' => true],
    'ajax_get_imported_content' => ['nonce' => true, 'limit' => true],
    'ajax_save_category' => ['nonce' => true, 'name' => true, 'description' => true, 'color' => true, 'icon' => true],
    'ajax_get_categories' => ['nonce' => true],
    'ajax_delete_category' => ['nonce' => true, 'id' => true],
    'ajax_save_quick_idea' => ['nonce' => true, 'title' => true, 'description' => true, 'category' => true, 'priority' => true],
    'ajax_save_idea' => ['nonce' => true, 'title' => true, 'content' => true, 'category' => true, 'priority' => true, 'status' => true, 'tags' => true],
    'ajax_get_ideas' => ['nonce' => true],
    'ajax_update_idea_status' => ['nonce' => true, 'idea_id' => true, 'status' => true],
    'ajax_delete_idea' => ['nonce' => true, 'id' => true]
];

$signature_results = [];

foreach ($method_tests as $method => $expected_params) {
    $method_start = strpos($admin_file, "public function $method");
    if ($method_start !== false) {
        $method_end = strpos($admin_file, '}', $method_start);
        $method_content = substr($admin_file, $method_start, $method_end - $method_start);

        $found_params = [];
        foreach ($expected_params as $param => $required) {
            if (strpos($method_content, "\$_POST['$param']") !== false ||
                strpos($method_content, "\$_POST[\"$param\"]") !== false) {
                $found_params[] = $param;
            }
        }

        $passed = count($found_params) === count($expected_params);
        $signature_results[$method] = $passed ? 'PASS' : 'FAIL';
        echo "✓ $method: " . ($passed ? 'PASS' : 'FAIL') . " (Found " . count($found_params) . "/" . count($expected_params) . " params)\n";
    } else {
        $signature_results[$method] = 'MISSING';
        echo "✗ $method: MISSING\n";
    }
}

// Test 4: Verify security checks
echo "\n=== Testing Security Checks ===\n";

$security_checks = [
    'check_ajax_referer' => 0,
    'current_user_can' => 0,
    'sanitize_text_field' => 0,
    'sanitize_textarea_field' => 0,
    'intval' => 0,
    'absint' => 0
];

foreach ($security_checks as $check => $count) {
    $count = substr_count($admin_file, $check);
    $security_checks[$check] = $count;
    echo "✓ $check: Found $count occurrences\n";
}

// Generate Test Report
echo "\n" . str_repeat("=", 60) . "\n";
echo "SIMPLE AJAX OPERATIONS TEST REPORT\n";
echo str_repeat("=", 60) . "\n";

echo "\nMethod Existence Test:\n";
echo "Found: " . count($found_methods) . "/" . count($ajax_methods) . "\n";
if (!empty($missing_methods)) {
    echo "Missing methods: " . implode(', ', $missing_methods) . "\n";
}

echo "\nAction Hook Registration Test:\n";
echo "Found: " . count($found_actions) . "/" . count($ajax_actions) . "\n";
if (!empty($missing_actions)) {
    echo "Missing actions: " . implode(', ', $missing_actions) . "\n";
}

echo "\nMethod Signature Test:\n";
$passed_signatures = array_filter($signature_results, function($result) { return $result === 'PASS'; });
$failed_signatures = array_filter($signature_results, function($result) { return $result === 'FAIL'; });
$missing_signatures = array_filter($signature_results, function($result) { return $result === 'MISSING'; });

echo "Passed: " . count($passed_signatures) . "\n";
echo "Failed: " . count($failed_signatures) . "\n";
echo "Missing: " . count($missing_signatures) . "\n";

echo "\nSecurity Check Test:\n";
foreach ($security_checks as $check => $count) {
    echo "$check: $count occurrences\n";
}

$total_tests = count($ajax_methods) + count($ajax_actions) + count($method_tests);
$total_passed = count($found_methods) + count($found_actions) + count($passed_signatures);
$success_rate = ($total_passed / $total_tests) * 100;

echo "\n" . str_repeat("-", 60) . "\n";
echo "OVERALL RESULTS:\n";
echo "Total Tests: $total_tests\n";
echo "Passed: $total_passed\n";
echo "Success Rate: " . round($success_rate, 1) . "%\n";

if ($success_rate >= 90) {
    echo "\n🎉 AJAX OPERATIONS TEST PASSED! The Content Organizer AJAX structure is properly implemented.\n";
} else {
    echo "\n⚠️  Some tests failed. Please review the results above.\n";
}

echo str_repeat("=", 60) . "\n";