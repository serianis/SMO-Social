<?php
/**
 * Test API Key Validation Endpoint
 * Tests the server-side API key validation AJAX endpoint
 */

require_once dirname(__DIR__) . '/smo-social.php';

class APIKeyValidationTest {
    private $results = [];

    public function __construct() {
        echo "\n=== SMO Social API Key Validation Endpoint Test ===\n";
        echo "Testing server-side API key validation endpoint\n";
        echo "Time: " . date('Y-m-d H:i:s') . "\n\n";
    }

    public function run_tests() {
        $this->test_openai_key_validation();
        $this->test_huggingface_key_validation();
        $this->test_openrouter_key_validation();
        $this->test_invalid_key_validation();
        $this->test_empty_key_validation();
        $this->test_unknown_provider_validation();

        $this->print_summary();
    }

    private function test_openai_key_validation() {
        echo "Test 1: OpenAI API Key Validation\n";
        echo str_repeat('-', 50) . "\n";

        // Valid OpenAI key format
        $valid_key = 'sk-' . str_repeat('x', 48);
        $result = $this->simulate_ajax_call('openai', $valid_key);

        if ($result['success'] && $result['data']['valid']) {
            $this->pass("Valid OpenAI key accepted");
        } else {
            $this->fail("Valid OpenAI key rejected: " . ($result['data']['error'] ?? 'Unknown error'));
        }

        // Invalid OpenAI key format
        $invalid_key = 'invalid-openai-key';
        $result = $this->simulate_ajax_call('openai', $invalid_key);

        if (!$result['success'] && isset($result['data']['valid']) && !$result['data']['valid']) {
            $this->pass("Invalid OpenAI key correctly rejected");
        } else {
            $this->fail("Invalid OpenAI key incorrectly accepted");
        }

        echo "\n";
    }

    private function test_huggingface_key_validation() {
        echo "Test 2: HuggingFace API Key Validation\n";
        echo str_repeat('-', 50) . "\n";

        // Valid HuggingFace key format
        $valid_key = 'hf_' . str_repeat('x', 34);
        $result = $this->simulate_ajax_call('huggingface', $valid_key);

        if ($result['success'] && $result['data']['valid']) {
            $this->pass("Valid HuggingFace key accepted");
        } else {
            $this->fail("Valid HuggingFace key rejected: " . ($result['data']['error'] ?? 'Unknown error'));
        }

        echo "\n";
    }

    private function test_openrouter_key_validation() {
        echo "Test 3: OpenRouter API Key Validation\n";
        echo str_repeat('-', 50) . "\n";

        // Valid OpenRouter key format
        $valid_key = 'sk-or-v1-' . str_repeat('x', 64);
        $result = $this->simulate_ajax_call('openrouter', $valid_key);

        if ($result['success'] && $result['data']['valid']) {
            $this->pass("Valid OpenRouter key accepted");
        } else {
            $this->fail("Valid OpenRouter key rejected: " . ($result['data']['error'] ?? 'Unknown error'));
        }

        echo "\n";
    }

    private function test_invalid_key_validation() {
        echo "Test 4: Invalid Key Validation\n";
        echo str_repeat('-', 50) . "\n";

        $invalid_key = 'invalid-key-format';
        $result = $this->simulate_ajax_call('openai', $invalid_key);

        if (!$result['success'] && isset($result['data']['valid']) && !$result['data']['valid']) {
            $this->pass("Invalid key correctly rejected with error message");
        } else {
            $this->fail("Invalid key incorrectly accepted");
        }

        echo "\n";
    }

    private function test_empty_key_validation() {
        echo "Test 5: Empty Key Validation\n";
        echo str_repeat('-', 50) . "\n";

        $result = $this->simulate_ajax_call('openai', '');

        if (!$result['success'] && isset($result['data']['valid']) && !$result['data']['valid']) {
            $this->pass("Empty key correctly rejected");
        } else {
            $this->fail("Empty key incorrectly accepted");
        }

        echo "\n";
    }

    private function test_unknown_provider_validation() {
        echo "Test 6: Unknown Provider Validation\n";
        echo str_repeat('-', 50) . "\n";

        $valid_key = str_repeat('x', 32);
        $result = $this->simulate_ajax_call('unknown_provider', $valid_key);

        if ($result['success'] && $result['data']['valid']) {
            $this->pass("Unknown provider falls back to generic validation");
        } else {
            $this->fail("Unknown provider validation failed: " . ($result['data']['error'] ?? 'Unknown error'));
        }

        echo "\n";
    }

    private function simulate_ajax_call($provider, $api_key) {
        // Simulate the AJAX request by calling the method directly
        try {
            // Create admin instance
            $admin = new \SMO_Social\Admin\Admin();

            // Simulate $_POST data
            $_POST['api_key'] = $api_key;
            $_POST['provider'] = $provider;
            $_POST['nonce'] = wp_create_nonce('smo_social_nonce');

            // Capture output
            ob_start();
            $admin->ajax_validate_api_key();
            $output = ob_get_clean();

            // Parse JSON response
            $response = json_decode($output, true);

            if ($response === null) {
                return ['success' => false, 'data' => ['error' => 'Invalid JSON response']];
            }

            return ['success' => $response['success'] ?? false, 'data' => $response['data'] ?? []];

        } catch (\Exception $e) {
            return ['success' => false, 'data' => ['error' => $e->getMessage()]];
        }
    }

    private function pass($message) {
        echo "✓ PASS: {$message}\n";
        $this->results[] = ['status' => 'pass', 'message' => $message];
    }

    private function fail($message) {
        echo "✗ FAIL: {$message}\n";
        $this->results[] = ['status' => 'fail', 'message' => $message];
    }

    private function print_summary() {
        echo "\n" . str_repeat('=', 50) . "\n";
        echo "TEST SUMMARY\n";
        echo str_repeat('=', 50) . "\n\n";

        $passed = count(array_filter($this->results, fn($r) => $r['status'] === 'pass'));
        $failed = count(array_filter($this->results, fn($r) => $r['status'] === 'fail'));
        $total = count($this->results);

        echo "Total Tests: {$total}\n";
        echo "Passed: {$passed}\n";
        echo "Failed: {$failed}\n\n";

        $success_rate = $total > 0 ? round(($passed / $total) * 100, 1) : 0;
        echo "Success Rate: {$success_rate}%\n\n";

        if ($failed === 0) {
            echo "🎉 All tests passed!\n";
        } else {
            echo "❌ Some tests failed.\n";
        }

        echo "\n";
    }
}

// Run tests
if (php_sapi_name() === 'cli' || (defined('WP_CLI') && constant('WP_CLI'))) {
    $test = new APIKeyValidationTest();
    $test->run_tests();
} else {
    echo "This test should be run from the command line or WP-CLI.\n";
}
