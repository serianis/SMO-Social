<?php
/**
 * Direct API Key Validator Test
 * Tests the APIKeyFormatValidator class directly without WordPress
 */

require_once __DIR__ . '/../includes/Security/APIKeyFormatValidator.php';

class APIKeyValidatorDirectTest {
    private $validator;
    private $results = [];

    public function __construct() {
        echo "\n=== SMO Social API Key Validator Direct Test ===\n";
        echo "Testing APIKeyFormatValidator class directly\n";
        echo "Time: " . date('Y-m-d H:i:s') . "\n\n";

        $this->validator = new SMO_Social\Security\APIKeyFormatValidator();
    }

    public function run_tests() {
        $this->test_openai_validation();
        $this->test_huggingface_validation();
        $this->test_openrouter_validation();
        $this->test_invalid_keys();
        $this->test_empty_keys();
        $this->test_generic_validation();

        $this->print_summary();
    }

    private function test_openai_validation() {
        echo "Test 1: OpenAI Key Validation\n";
        echo str_repeat('-', 40) . "\n";

        // Valid OpenAI key
        $valid_key = 'sk-' . str_repeat('a', 48);
        $result = $this->validator->validate_key_format($valid_key, 'openai');

        if ($result['valid']) {
            $this->pass("Valid OpenAI key accepted");
        } else {
            $this->fail("Valid OpenAI key rejected: " . $result['error']);
        }

        // Invalid OpenAI key
        $invalid_key = 'invalid-openai-key';
        $result = $this->validator->validate_key_format($invalid_key, 'openai');

        if (!$result['valid']) {
            $this->pass("Invalid OpenAI key correctly rejected");
        } else {
            $this->fail("Invalid OpenAI key incorrectly accepted");
        }

        echo "\n";
    }

    private function test_huggingface_validation() {
        echo "Test 2: HuggingFace Key Validation\n";
        echo str_repeat('-', 40) . "\n";

        // Valid HuggingFace key
        $valid_key = 'hf_' . str_repeat('b', 34);
        $result = $this->validator->validate_key_format($valid_key, 'huggingface');

        if ($result['valid']) {
            $this->pass("Valid HuggingFace key accepted");
        } else {
            $this->fail("Valid HuggingFace key rejected: " . $result['error']);
        }

        echo "\n";
    }

    private function test_openrouter_validation() {
        echo "Test 3: OpenRouter Key Validation\n";
        echo str_repeat('-', 40) . "\n";

        // Valid OpenRouter key
        $valid_key = 'sk-or-v1-' . str_repeat('c', 64);
        $result = $this->validator->validate_key_format($valid_key, 'openrouter');

        if ($result['valid']) {
            $this->pass("Valid OpenRouter key accepted");
        } else {
            $this->fail("Valid OpenRouter key rejected: " . $result['error']);
        }

        echo "\n";
    }

    private function test_invalid_keys() {
        echo "Test 4: Invalid Keys\n";
        echo str_repeat('-', 40) . "\n";

        $invalid_keys = [
            'openai' => 'not-a-valid-openai-key',
            'huggingface' => 'not-a-valid-hf-key',
            'openrouter' => 'not-a-valid-or-key'
        ];

        foreach ($invalid_keys as $provider => $key) {
            $result = $this->validator->validate_key_format($key, $provider);
            if (!$result['valid']) {
                $this->pass("Invalid {$provider} key correctly rejected");
            } else {
                $this->fail("Invalid {$provider} key incorrectly accepted");
            }
        }

        echo "\n";
    }

    private function test_empty_keys() {
        echo "Test 5: Empty Keys\n";
        echo str_repeat('-', 40) . "\n";

        $result = $this->validator->validate_key_format('', 'openai');

        if (!$result['valid'] && strpos($result['error'], 'empty') !== false) {
            $this->pass("Empty key correctly rejected");
        } else {
            $this->fail("Empty key not handled correctly");
        }

        echo "\n";
    }

    private function test_generic_validation() {
        echo "Test 6: Generic Validation\n";
        echo str_repeat('-', 40) . "\n";

        // Valid generic key
        $valid_key = str_repeat('x', 32);
        $result = $this->validator->validate_key_format($valid_key, 'unknown_provider');

        if ($result['valid']) {
            $this->pass("Generic validation works for unknown provider");
        } else {
            $this->fail("Generic validation failed: " . $result['error']);
        }

        // Too short generic key
        $short_key = 'abc';
        $result = $this->validator->validate_key_format($short_key, 'unknown_provider');

        if (!$result['valid']) {
            $this->pass("Too short generic key correctly rejected");
        } else {
            $this->fail("Too short generic key incorrectly accepted");
        }

        echo "\n";
    }

    private function pass($message) {
        echo "✓ PASS: {$message}\n";
        $this->results[] = ['status' => 'pass', 'message' => $message];
    }

    private function fail($message) {
        echo "✗ FAIL: {$message}\n";
        $this->results[] = ['status' => 'fail', 'message' => $message];
    }

    private function print_summary() {
        echo "\n" . str_repeat('=', 50) . "\n";
        echo "TEST SUMMARY\n";
        echo str_repeat('=', 50) . "\n\n";

        $passed = count(array_filter($this->results, fn($r) => $r['status'] === 'pass'));
        $failed = count(array_filter($this->results, fn($r) => $r['status'] === 'fail'));
        $total = count($this->results);

        echo "Total Tests: {$total}\n";
        echo "Passed: {$passed}\n";
        echo "Failed: {$failed}\n\n";

        $success_rate = $total > 0 ? round(($passed / $total) * 100, 1) : 0;
        echo "Success Rate: {$success_rate}%\n\n";

        if ($failed === 0) {
            echo "🎉 All tests passed!\n";
        } else {
            echo "❌ Some tests failed.\n";
        }

        echo "\n";
    }
}

// Run the test
$test = new APIKeyValidatorDirectTest();
$test->run_tests();