<?php
/**
 * Test Bounded Cache Implementation for SMO Social
 *
 * Comprehensive test suite for bounded cache systems with automatic eviction policies
 *
 * @package SMO_Social
 * @subpackage Tests
 */

require_once __DIR__ . '/../includes/AI/BoundedCacheManager.php';
require_once __DIR__ . '/../includes/Core/BoundedRedisCache.php';
require_once __DIR__ . '/../includes/Core/BoundedCacheObjectPool.php';
require_once __DIR__ . '/../includes/Core/BoundedCacheConfig.php';

class BoundedCacheTest {
    private $test_results = [];
    private $start_time;

    public function __construct() {
        $this->start_time = microtime(true);
        echo "Starting Bounded Cache Implementation Tests...\n";
    }

    /**
     * Run all tests
     */
    public function run_all_tests() {
        $this->test_ai_bounded_cache_manager();
        $this->test_core_bounded_redis_cache();
        $this->test_bounded_cache_object_pool();
        $this->test_bounded_cache_config();
        $this->test_lru_eviction_policies();
        $this->test_cache_size_monitoring();
        $this->test_error_handling();
        $this->test_statistics_tracking();

        $this->print_test_results();
    }

    /**
     * Test AI Bounded Cache Manager
     */
    private function test_ai_bounded_cache_manager() {
        echo "Testing AI Bounded Cache Manager...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager(1048576, 10); // 1MB, 10MB

            // Test basic operations
            $test_key = 'test_key_' . time();
            $test_data = ['test' => 'data', 'timestamp' => time()];

            // Test set
            $set_result = $cache_manager->set($test_key, $test_data, 300);
            $this->test_results['ai_cache']['set_operation'] = $set_result;

            // Test get
            $get_result = $cache_manager->get($test_key);
            $this->test_results['ai_cache']['get_operation'] = ($get_result === $test_data);

            // Test delete
            $delete_result = $cache_manager->delete($test_key);
            $this->test_results['ai_cache']['delete_operation'] = $delete_result;

            // Test stats
            $stats = $cache_manager->get_stats();
            $this->test_results['ai_cache']['stats_available'] = is_array($stats);

            // Test cache size management
            $cache_manager->set_max_cache_size(2097152); // 2MB
            $max_size = $cache_manager->get_max_cache_size();
            $this->test_results['ai_cache']['size_management'] = ($max_size === 2097152);

            echo "AI Bounded Cache Manager tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['ai_cache']['error'] = $e->getMessage();
            error_log('AI Bounded Cache Manager test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Core Bounded Redis Cache
     */
    private function test_core_bounded_redis_cache() {
        echo "Testing Core Bounded Redis Cache...\n";

        try {
            // Create mock Redis instance for testing
            $mock_redis = $this->create_mock_redis();

            $redis_cache = new \SMO_Social\Core\BoundedRedisCache($mock_redis, 5242880, 10); // 5MB, 10MB

            // Test basic operations
            $test_key = 'test_redis_key_' . time();
            $test_data = ['redis' => 'test', 'value' => rand(1, 1000)];

            // Test set
            $set_result = $redis_cache->set($test_key, $test_data, 300);
            $this->test_results['redis_cache']['set_operation'] = $set_result;

            // Test get
            $get_result = $redis_cache->get($test_key);
            $this->test_results['redis_cache']['get_operation'] = ($get_result === $test_data);

            // Test delete
            $delete_result = $redis_cache->delete($test_key);
            $this->test_results['redis_cache']['delete_operation'] = $delete_result;

            // Test stats
            $stats = $redis_cache->get_stats();
            $this->test_results['redis_cache']['stats_available'] = is_array($stats);

            // Test cache size management
            $redis_cache->set_max_cache_size(1048576); // 1MB
            $max_size = $redis_cache->get_max_cache_size();
            $this->test_results['redis_cache']['size_management'] = ($max_size === 1048576);

            echo "Core Bounded Redis Cache tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['redis_cache']['error'] = $e->getMessage();
            error_log('Core Bounded Redis Cache test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Bounded Cache Object Pool
     */
    private function test_bounded_cache_object_pool() {
        echo "Testing Bounded Cache Object Pool...\n";

        try {
            $object_pool = new \SMO_Social\Core\BoundedCacheObjectPool(10, 300, 10); // Small pool, 5min timeout, 10MB

            // Test basic operations
            $obj1 = $object_pool->get_cache_object();
            $this->test_results['object_pool']['get_object_1'] = ($obj1 !== null);

            $obj2 = $object_pool->get_cache_object();
            $this->test_results['object_pool']['get_object_2'] = ($obj2 !== null);

            // Test release
            $release_result = $object_pool->release_cache_object($obj1);
            $this->test_results['object_pool']['release_object'] = $release_result;

            // Test stats
            $stats = $object_pool->get_stats();
            $this->test_results['object_pool']['stats_available'] = is_array($stats);

            // Test memory management
            $object_pool->set_max_memory_usage(20); // 20MB
            $max_memory = $object_pool->get_max_memory_usage();
            $this->test_results['object_pool']['memory_management'] = ($max_memory === 20);

            // Test pool size management
            $object_pool->set_max_pool_size(15);
            $pool_size = $object_pool->get_current_pool_size();
            $this->test_results['object_pool']['pool_size_management'] = ($pool_size <= 15);

            echo "Bounded Cache Object Pool tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['object_pool']['error'] = $e->getMessage();
            error_log('Bounded Cache Object Pool test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Bounded Cache Configuration
     */
    private function test_bounded_cache_config() {
        echo "Testing Bounded Cache Configuration...\n";

        try {
            $config = new \SMO_Social\Core\BoundedCacheConfig();

            // Test configuration loading
            $ai_config = $config->get_config('ai_cache');
            $this->test_results['config']['ai_config_available'] = is_array($ai_config);

            $redis_config = $config->get_config('redis_cache');
            $this->test_results['config']['redis_config_available'] = is_array($redis_config);

            $pool_config = $config->get_config('object_pool');
            $this->test_results['config']['pool_config_available'] = is_array($pool_config);

            // Test cache instances
            $ai_cache = $config->get_ai_cache_manager();
            $this->test_results['config']['ai_cache_instance'] = ($ai_cache !== null);

            $redis_cache = $config->get_redis_cache();
            $this->test_results['config']['redis_cache_instance'] = ($redis_cache !== null);

            $object_pool = $config->get_object_pool();
            $this->test_results['config']['object_pool_instance'] = ($object_pool !== null);

            // Test configuration management
            $config->set_eviction_policy('ai_cache', 'lru');
            $policy = $config->get_eviction_policy('ai_cache');
            $this->test_results['config']['eviction_policy'] = ($policy === 'lru');

            echo "Bounded Cache Configuration tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['config']['error'] = $e->getMessage();
            error_log('Bounded Cache Configuration test error: ' . $e->getMessage());
        }
    }

    /**
     * Test LRU Eviction Policies
     */
    private function test_lru_eviction_policies() {
        echo "Testing LRU Eviction Policies...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager(1048576, 10); // 1MB limit

            // Fill cache to trigger eviction
            for ($i = 0; $i < 100; $i++) {
                $cache_manager->set('eviction_test_key_' . $i, ['data' => $i, 'timestamp' => time()], 60);
            }

            // Check if eviction occurred
            $stats = $cache_manager->get_stats();
            $evictions = $stats['operations']['evictions'] ?? 0;
            $this->test_results['lru_eviction']['evictions_occurred'] = ($evictions > 0);

            // Test LRU tracking
            $lru_stats = $cache_manager->get_lru_stats();
            $this->test_results['lru_eviction']['lru_tracking_active'] = is_array($lru_stats);

            echo "LRU Eviction Policy tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['lru_eviction']['error'] = $e->getMessage();
            error_log('LRU Eviction Policy test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Cache Size Monitoring
     */
    private function test_cache_size_monitoring() {
        echo "Testing Cache Size Monitoring...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager(2097152, 10); // 2MB limit

            // Test initial size
            $initial_size = $cache_manager->get_current_cache_size();
            $this->test_results['size_monitoring']['initial_size_valid'] = ($initial_size >= 0);

            // Add some data
            for ($i = 0; $i < 10; $i++) {
                $cache_manager->set('size_test_' . $i, str_repeat('x', 1000), 60); // 1KB each
            }

            // Test size after adding data
            $current_size = $cache_manager->get_current_cache_size();
            $this->test_results['size_monitoring']['size_increased'] = ($current_size > $initial_size);

            // Test size limits
            $max_size = $cache_manager->get_max_cache_size();
            $this->test_results['size_monitoring']['max_size_valid'] = ($max_size === 2097152);

            // Test size percentage
            $stats = $cache_manager->get_stats();
            $percentage = $stats['cache_size_percentage'] ?? 0;
            $this->test_results['size_monitoring']['percentage_valid'] = ($percentage >= 0 && $percentage <= 100);

            echo "Cache Size Monitoring tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['size_monitoring']['error'] = $e->getMessage();
            error_log('Cache Size Monitoring test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Error Handling
     */
    private function test_error_handling() {
        echo "Testing Error Handling...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager();

            // Test invalid operations
            $result = $cache_manager->get('nonexistent_key');
            $this->test_results['error_handling']['nonexistent_key'] = ($result === false);

            // Test delete nonexistent key
            $delete_result = $cache_manager->delete('nonexistent_key');
            $this->test_results['error_handling']['delete_nonexistent'] = $delete_result;

            // Test stats after operations
            $stats = $cache_manager->get_current_stats();
            $this->test_results['error_handling']['stats_tracking'] = is_array($stats);

            echo "Error Handling tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['error_handling']['error'] = $e->getMessage();
            error_log('Error Handling test error: ' . $e->getMessage());
        }
    }

    /**
     * Test Statistics Tracking
     */
    private function test_statistics_tracking() {
        echo "Testing Statistics Tracking...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager();

            // Perform operations to generate stats
            $cache_manager->set('stats_test_1', ['data' => 1], 60);
            $cache_manager->get('stats_test_1');
            $cache_manager->set('stats_test_2', ['data' => 2], 60);
            $cache_manager->get('stats_test_2');
            $cache_manager->delete('stats_test_1');

            // Check statistics
            $stats = $cache_manager->get_stats();
            $operations = $stats['operations'] ?? [];

            $this->test_results['statistics']['hits_tracked'] = isset($operations['hits']);
            $this->test_results['statistics']['misses_tracked'] = isset($operations['misses']);
            $this->test_results['statistics']['sets_tracked'] = isset($operations['sets']);
            $this->test_results['statistics']['deletes_tracked'] = isset($operations['deletes']);
            $this->test_results['statistics']['evictions_tracked'] = isset($operations['evictions']);

            // Check hit rate calculation
            $hit_rate = $cache_manager->get_hit_rate();
            $this->test_results['statistics']['hit_rate_calculated'] = is_numeric($hit_rate);

            echo "Statistics Tracking tests completed.\n";

        } catch (Exception $e) {
            $this->test_results['statistics']['error'] = $e->getMessage();
            error_log('Statistics Tracking test error: ' . $e->getMessage());
        }
    }

    /**
     * Create mock Redis instance for testing
     */
    private function create_mock_redis() {
        // Create a simple mock Redis class for testing
        class MockRedis {
            private $data = [];
            private $ttl_data = [];

            public function ping() {
                return true;
            }

            public function get($key) {
                if (isset($this->data[$key])) {
                    if (!isset($this->ttl_data[$key]) || $this->ttl_data[$key] > time()) {
                        return $this->data[$key];
                    } else {
                        unset($this->data[$key]);
                        unset($this->ttl_data[$key]);
                    }
                }
                return false;
            }

            public function setex($key, $ttl, $value) {
                $this->data[$key] = $value;
                $this->ttl_data[$key] = time() + $ttl;
                return true;
            }

            public function del($key) {
                if (is_array($key)) {
                    $success = true;
                    foreach ($key as $k) {
                        if (isset($this->data[$k])) {
                            unset($this->data[$k]);
                            unset($this->ttl_data[$k]);
                        } else {
                            $success = false;
                        }
                    }
                    return $success;
                } else {
                    if (isset($this->data[$key])) {
                        unset($this->data[$key]);
                        unset($this->ttl_data[$key]);
                        return true;
                    }
                    return false;
                }
            }

            public function exists($key) {
                return isset($this->data[$key]) && (!isset($this->ttl_data[$key]) || $this->ttl_data[$key] > time());
            }

            public function keys($pattern) {
                $matches = [];
                foreach ($this->data as $key => $value) {
                    if (fnmatch($pattern, $key)) {
                        $matches[] = $key;
                    }
                }
                return $matches;
            }

            public function mget($keys) {
                $results = [];
                foreach ($keys as $key) {
                    $results[] = $this->get($key);
                }
                return $results;
            }

            public function pipeline() {
                return $this;
            }

            public function exec() {
                return array_fill(0, count($this->data), true);
            }

            public function dbsize() {
                return count($this->data);
            }

            public function info($section = null) {
                return [
                    'used_memory' => strlen(serialize($this->data)),
                    'connected_clients' => 1,
                    'uptime_in_seconds' => time() - $_SERVER['REQUEST_TIME'],
                    'redis_version' => '6.2.0'
                ];
            }

            public function strlen($key) {
                return isset($this->data[$key]) ? strlen($this->data[$key]) : 0;
            }
        }

        return new MockRedis();
    }

    /**
     * Print test results
     */
    private function print_test_results() {
        $end_time = microtime(true);
        $execution_time = $end_time - $this->start_time;

        echo "\n=== Bounded Cache Implementation Test Results ===\n";
        echo "Execution Time: " . round($execution_time, 2) . " seconds\n\n";

        $total_tests = 0;
        $passed_tests = 0;
        $failed_tests = 0;

        foreach ($this->test_results as $category => $tests) {
            echo "--- $category ---\n";
            foreach ($tests as $test => $result) {
                $total_tests++;
                if ($result === true) {
                    $passed_tests++;
                    echo "✓ $test: PASSED\n";
                } elseif ($result === false) {
                    $failed_tests++;
                    echo "✗ $test: FAILED\n";
                } elseif (is_string($result) && strpos($test, 'error') !== false) {
                    echo "! $test: ERROR - $result\n";
                } else {
                    echo "? $test: UNKNOWN - " . print_r($result, true) . "\n";
                }
            }
            echo "\n";
        }

        echo "=== Summary ===\n";
        echo "Total Tests: $total_tests\n";
        echo "Passed: $passed_tests\n";
        echo "Failed: $failed_tests\n";
        echo "Success Rate: " . ($total_tests > 0 ? round(($passed_tests / $total_tests) * 100, 2) : 0) . "%\n";

        if ($failed_tests === 0) {
            echo "\n🎉 All tests passed! Bounded cache implementation is working correctly.\n";
        } else {
            echo "\n⚠️  Some tests failed. Please review the implementation.\n";
        }
    }

    /**
     * Run performance benchmark
     */
    public function run_performance_benchmark() {
        echo "\nRunning Performance Benchmark...\n";

        try {
            $cache_manager = new \SMO_Social\AI\BoundedCacheManager(10485760, 50); // 10MB

            // Benchmark set operations
            $start = microtime(true);
            for ($i = 0; $i < 100; $i++) {
                $cache_manager->set('benchmark_' . $i, ['data' => $i, 'timestamp' => time()], 60);
            }
            $set_time = microtime(true) - $start;

            // Benchmark get operations
            $start = microtime(true);
            for ($i = 0; $i < 100; $i++) {
                $cache_manager->get('benchmark_' . $i);
            }
            $get_time = microtime(true) - $start;

            // Benchmark delete operations
            $start = microtime(true);
            for ($i = 0; $i < 100; $i++) {
                $cache_manager->delete('benchmark_' . $i);
            }
            $delete_time = microtime(true) - $start;

            echo "Performance Results:\n";
            echo "Set Operations (100): " . round($set_time * 1000, 2) . "ms\n";
            echo "Get Operations (100): " . round($get_time * 1000, 2) . "ms\n";
            echo "Delete Operations (100): " . round($delete_time * 1000, 2) . "ms\n";
            echo "Average per operation: " . round(($set_time + $get_time + $delete_time) * 1000 / 300, 2) . "ms\n";

        } catch (Exception $e) {
            error_log('Performance benchmark error: ' . $e->getMessage());
            echo "Performance benchmark failed: " . $e->getMessage() . "\n";
        }
    }
}

// Run the tests
$test_runner = new BoundedCacheTest();
$test_runner->run_all_tests();
$test_runner->run_performance_benchmark();

/**
 * Helper function to format test output
 */
function format_test_results($results) {
    $output = [];
    foreach ($results as $category => $tests) {
        $output[$category] = [];
        foreach ($tests as $test => $result) {
            $output[$category][$test] = [
                'result' => $result,
                'status' => $result === true ? 'PASS' : ($result === false ? 'FAIL' : 'ERROR')
            ];
        }
    }
    return $output;
}