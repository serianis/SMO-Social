<?php
/**
 * Database Validation Test for Content Organizer
 *
 * This test file verifies database operations, schema compatibility,
 * and data integrity for the Content Organizer feature.
 */

echo "Starting Database Validation Test...\n";

// Test 1: Verify database schema includes Content Organizer tables
echo "\n=== Testing Database Schema for Content Organizer Tables ===\n";

$schema_file = file_get_contents('includes/Database/DatabaseSchema.php');

$required_tables = [
    'smo_content_categories',
    'smo_content_ideas',
    'smo_imported_content',
    'smo_content_sources'
];

$found_tables = [];
$missing_tables = [];

foreach ($required_tables as $table) {
    if (strpos($schema_file, "CREATE TABLE .* $table") !== false) {
        $found_tables[] = $table;
        echo "✓ Found table: $table\n";
    } else {
        $missing_tables[] = $table;
        echo "✗ Missing table: $table\n";
    }
}

// Test 2: Verify table structures
echo "\n=== Testing Table Structures ===\n";

$table_structures = [
    'smo_content_categories' => [
        'id', 'user_id', 'name', 'description', 'color_code', 'icon', 'sort_order', 'is_active', 'created_at', 'updated_at'
    ],
    'smo_content_ideas' => [
        'id', 'user_id', 'title', 'content', 'category_id', 'priority', 'status', 'scheduled_date', 'tags', 'sort_order', 'created_at', 'updated_at'
    ],
    'smo_imported_content' => [
        'id', 'user_id', 'source_id', 'title', 'content', 'url', 'platform', 'imported_at', 'status', 'metadata'
    ],
    'smo_content_sources' => [
        'id', 'user_id', 'name', 'type', 'url', 'settings', 'status', 'last_imported', 'created_at', 'updated_at'
    ]
];

$structure_results = [];

foreach ($table_structures as $table => $expected_columns) {
    $table_start = strpos($schema_file, "CREATE TABLE .* $table");
    if ($table_start !== false) {
        $table_end = strpos($schema_file, ');', $table_start);
        $table_content = substr($schema_file, $table_start, $table_end - $table_start);

        $found_columns = [];
        foreach ($expected_columns as $column) {
            if (strpos($table_content, "`$column`") !== false ||
                strpos($table_content, "'$column'") !== false) {
                $found_columns[] = $column;
            }
        }

        $passed = count($found_columns) === count($expected_columns);
        $structure_results[$table] = $passed ? 'PASS' : 'FAIL';
        echo "✓ $table: " . ($passed ? 'PASS' : 'FAIL') . " (Found " . count($found_columns) . "/" . count($expected_columns) . " columns)\n";
    } else {
        $structure_results[$table] = 'MISSING';
        echo "✗ $table: MISSING\n";
    }
}

// Test 3: Verify database operations in Admin.php
echo "\n=== Testing Database Operations in Admin.php ===\n";

$admin_file = file_get_contents('includes/Admin/Admin.php');

$database_operations = [
    'global $wpdb' => 0,
    '$wpdb->get_var' => 0,
    '$wpdb->get_results' => 0,
    '$wpdb->get_row' => 0,
    '$wpdb->insert' => 0,
    '$wpdb->update' => 0,
    '$wpdb->delete' => 0,
    '$wpdb->prepare' => 0,
    'ARRAY_A' => 0,
    'OBJECT' => 0
];

foreach ($database_operations as $operation => $count) {
    $count = substr_count($admin_file, $operation);
    $database_operations[$operation] = $count;
    echo "✓ $operation: Found $count occurrences\n";
}

// Test 4: Verify Content Organizer specific database operations
echo "\n=== Testing Content Organizer Specific Database Operations ===\n";

$organizer_db_operations = [
    'smo_content_categories' => 0,
    'smo_content_ideas' => 0,
    'smo_imported_content' => 0,
    'smo_content_sources' => 0,
    'get_current_user_id()' => 0,
    'current_time(\'mysql\')' => 0
];

foreach ($organizer_db_operations as $operation => $count) {
    $count = substr_count($admin_file, $operation);
    $organizer_db_operations[$operation] = $count;
    echo "✓ $operation: Found $count occurrences\n";
}

// Test 5: Verify error handling in database operations
echo "\n=== Testing Database Error Handling ===\n";

$error_handling = [
    'try {' => 0,
    'catch (' => 0,
    'Exception' => 0,
    'wp_send_json_error' => 0,
    'wp_send_json_success' => 0,
    'if ($result === false)' => 0,
    'if (!$' => 0
];

foreach ($error_handling as $pattern => $count) {
    $count = substr_count($admin_file, $pattern);
    $error_handling[$pattern] = $count;
    echo "✓ $pattern: Found $count occurrences\n";
}

// Test 6: Verify data validation and sanitization
echo "\n=== Testing Data Validation and Sanitization ===\n";

$data_validation = [
    'sanitize_text_field' => 0,
    'sanitize_textarea_field' => 0,
    'intval' => 0,
    'absint' => 0,
    'json_encode' => 0,
    'json_decode' => 0,
    'empty(' => 0,
    'isset(' => 0
];

foreach ($data_validation as $validation => $count) {
    $count = substr_count($admin_file, $validation);
    $data_validation[$validation] = $count;
    echo "✓ $validation: Found $count occurrences\n";
}

// Generate Test Report
echo "\n" . str_repeat("=", 60) . "\n";
echo "DATABASE VALIDATION TEST REPORT\n";
echo str_repeat("=", 60) . "\n";

echo "\nDatabase Schema Test:\n";
echo "Found: " . count($found_tables) . "/" . count($required_tables) . "\n";
if (!empty($missing_tables)) {
    echo "Missing tables: " . implode(', ', $missing_tables) . "\n";
}

echo "\nTable Structure Test:\n";
$passed_structures = array_filter($structure_results, function($result) { return $result === 'PASS'; });
$failed_structures = array_filter($structure_results, function($result) { return $result === 'FAIL'; });
$missing_structures = array_filter($structure_results, function($result) { return $result === 'MISSING'; });

echo "Passed: " . count($passed_structures) . "\n";
echo "Failed: " . count($failed_structures) . "\n";
echo "Missing: " . count($missing_structures) . "\n";

echo "\nDatabase Operations Test:\n";
$total_db_operations = array_sum($database_operations);
echo "Total database operations found: $total_db_operations\n";

echo "\nContent Organizer Specific Operations:\n";
$total_organizer_ops = array_sum($organizer_db_operations);
echo "Total Content Organizer operations found: $total_organizer_ops\n";

echo "\nError Handling Test:\n";
$total_error_handling = array_sum($error_handling);
echo "Total error handling patterns found: $total_error_handling\n";

echo "\nData Validation Test:\n";
$total_validation = array_sum($data_validation);
echo "Total data validation patterns found: $total_validation\n";

$total_tests = count($required_tables) + count($table_structures) + count($database_operations) + count($organizer_db_operations);
$total_passed = count($found_tables) + count($passed_structures) + $total_db_operations + $total_organizer_ops;
$success_rate = ($total_passed / $total_tests) * 100;

echo "\n" . str_repeat("-", 60) . "\n";
echo "OVERALL RESULTS:\n";
echo "Total Tests: $total_tests\n";
echo "Passed: $total_passed\n";
echo "Success Rate: " . round($success_rate, 1) . "%\n";

if ($success_rate >= 80) {
    echo "\n🎉 DATABASE VALIDATION TEST PASSED! The Content Organizer database operations are properly implemented.\n";
} else {
    echo "\n⚠️  Some tests failed. Please review the results above.\n";
}

echo str_repeat("=", 60) . "\n";

// Additional detailed analysis
echo "\n=== DETAILED ANALYSIS ===\n";

echo "\nDatabase Schema Coverage:\n";
foreach ($required_tables as $table) {
    $coverage = in_array($table, $found_tables) ? "✓ COVERED" : "✗ MISSING";
    echo "$table: $coverage\n";
}

echo "\nCritical Database Operations:\n";
$critical_ops = [
    'global $wpdb' => $database_operations['global $wpdb'],
    '$wpdb->prepare' => $database_operations['$wpdb->prepare'],
    'try/catch blocks' => $error_handling['try {'] + $error_handling['catch ('],
    'Error responses' => $error_handling['wp_send_json_error']
];

foreach ($critical_ops as $op => $count) {
    $status = $count > 0 ? "✓ ADEQUATE" : "✗ INADEQUATE";
    echo "$op: $count occurrences - $status\n";
}

echo "\nSecurity Measures:\n";
$security_measures = [
    'Data sanitization' => $data_validation['sanitize_text_field'] + $data_validation['sanitize_textarea_field'],
    'Input validation' => $data_validation['empty('] + $data_validation['isset('],
    'Type conversion' => $data_validation['intval'] + $data_validation['absint'],
    'Error handling' => $error_handling['try {'] + $error_handling['catch (']
];

foreach ($security_measures as $measure => $count) {
    $status = $count > 5 ? "✓ STRONG" : ($count > 0 ? "⚠️  MODERATE" : "✗ WEAK");
    echo "$measure: $count occurrences - $status\n";
}

echo str_repeat("=", 60) . "\n";