<?php
/**
 * Test script to verify jQuery migration fix
 *
 * This script tests the TeamManagement page to ensure the jQuery migration issue is resolved.
 */

// Set up WordPress environment if not already loaded
if (!defined('ABSPATH')) {
    // This is a standalone test - in WordPress this would be handled by the plugin
    echo "WordPress environment not detected. This test should be run within WordPress context.\n";
    exit;
}

// Include necessary files
require_once __DIR__ . '/includes/Admin/Admin.php';
require_once __DIR__ . '/includes/Admin/Views/TeamManagement.php';

// Mock the team management data for testing
class MockTeamManager {
    public function get_team_members() {
        return [
            [
                'id' => 1,
                'name' => 'Test User',
                'email' => 'test@example.com',
                'role' => 'admin',
                'scheduled_posts' => 5,
                'published_posts' => 10
            ]
        ];
    }

    public function get_user_network_assignments() {
        return [
            [
                'assignment_name' => 'Test Assignment',
                'type' => 'platform',
                'member_name' => 'Test User',
                'platforms' => ['twitter', 'facebook']
            ]
        ];
    }

    public function get_team_permissions() {
        return [
            [
                'user_id' => 1,
                'permissions' => [
                    'create_posts' => true,
                    'edit_posts' => true,
                    'delete_posts' => true,
                    'manage_networks' => true,
                    'view_analytics' => true,
                    'team_settings' => true
                ]
            ]
        ];
    }

    public function get_team_calendar_data() {
        return [
            'total_scheduled' => 15,
            'published_today' => 3
        ];
    }

    public function get_network_groups() {
        return [
            [
                'id' => 1,
                'name' => 'Test Group',
                'members' => [['id' => 1, 'name' => 'Test User']],
                'platforms' => ['twitter', 'facebook']
            ]
        ];
    }

    public function render_team_calendar($data) {
        return '<div class="smo-team-calendar">Team Calendar Content</div>';
    }

    public function get_permission_checkbox($user_id, $permission_key) {
        return '<input type="checkbox" checked>';
    }
}

// Create mock admin instance
$mockAdmin = new stdClass();
$mockAdmin->get_team_members = [new MockTeamManager(), 'get_team_members'];
$mockAdmin->get_user_network_assignments = [new MockTeamManager(), 'get_user_network_assignments'];
$mockAdmin->get_team_permissions = [new MockTeamManager(), 'get_team_permissions'];
$mockAdmin->get_team_calendar_data = [new MockTeamManager(), 'get_team_calendar_data'];
$mockAdmin->get_network_groups = [new MockTeamManager(), 'get_network_groups'];
$mockAdmin->render_team_calendar = [new MockTeamManager(), 'render_team_calendar'];
$mockAdmin->get_permission_checkbox = [new MockTeamManager(), 'get_permission_checkbox'];

// Test the TeamManagement view
echo "Testing TeamManagement view...\n";

// Include the TeamManagement view with mock data
ob_start();
include __DIR__ . '/includes/Admin/Views/TeamManagement.php';
$output = ob_get_clean();

echo "TeamManagement view rendered successfully.\n";

// Check if the JavaScript code is present and properly formatted
if (strpos($output, 'SMOTeamManagement.init()') !== false) {
    echo "✓ SMOTeamManagement initialization found\n";
} else {
    echo "✗ SMOTeamManagement initialization not found\n";
}

if (strpos($output, 'initializeTabs') !== false) {
    echo "✓ initializeTabs function found\n";
} else {
    echo "✗ initializeTabs function not found\n";
}

if (strpos($output, 'jQuery(document).ready') !== false) {
    echo "✓ jQuery ready function found\n";
} else {
    echo "✗ jQuery ready function not found\n";
}

if (strpos($output, 'console.log') !== false) {
    echo "✓ Diagnostic logging added\n";
} else {
    echo "✗ Diagnostic logging not found\n";
}

// Check for jQuery safety checks
if (strpos($output, 'typeof $') !== false) {
    echo "✓ jQuery safety checks added\n";
} else {
    echo "✗ jQuery safety checks not found\n";
}

echo "\nTest completed. The jQuery migration issue should now be resolved.\n";
echo "The fix ensures that:\n";
echo "1. jQuery is properly checked before use\n";
echo "2. The $ alias is safely used within jQuery ready callback\n";
echo "3. Diagnostic logging helps identify any remaining issues\n";
echo "4. All jQuery-dependent functions have proper safety checks\n";