<?php
/**
 * Test Memory-Efficient Data Structures Implementation
 *
 * Comprehensive test suite for verifying memory-efficient data structures
 * and streaming implementations across the SMO-Social project.
 */

if (!defined('ABSPATH')) {
    exit; // Security check
}

// Include necessary files
require_once __DIR__ . '/../includes/Analytics/AnalyticsDataStream.php';
require_once __DIR__ . '/../includes/Content/ContentImportStream.php';
require_once __DIR__ . '/../includes/Core/CacheMetadataStream.php';
require_once __DIR__ . '/../includes/Core/MemoryEfficientConfig.php';
require_once __DIR__ . '/../includes/Core/ResourceCleanupManager.php';
require_once __DIR__ . '/../includes/Analytics/Processor.php';
require_once __DIR__ . '/../includes/Analytics/Collector.php';
require_once __DIR__ . '/../includes/Content/ContentImportManager.php';
require_once __DIR__ . '/../includes/AI/CacheManager.php';
require_once __DIR__ . '/../includes/Core/CacheManager.php';

class MemoryEfficientTestSuite {
    private $test_results;
    private $start_time;
    private $memory_usage_start;
    private $logger;

    public function __construct() {
        $this->test_results = array();
        $this->start_time = microtime(true);
        $this->memory_usage_start = memory_get_usage(true);
        $this->logger = new MemoryEfficientTestLogger();

        $this->logger->log("Starting Memory-Efficient Data Structures Test Suite");
    }

    /**
     * Run all tests
     */
    public function run_all_tests() {
        $this->test_results['start_time'] = $this->start_time;
        $this->test_results['memory_usage_start'] = $this->memory_usage_start;

        $this->test_analytics_data_stream();
        $this->test_content_import_stream();
        $this->test_cache_metadata_stream();
        $this->test_memory_efficient_config();
        $this->test_resource_cleanup_manager();
        $this->test_integration_scenarios();

        $this->test_results['end_time'] = microtime(true);
        $this->test_results['memory_usage_end'] = memory_get_usage(true);
        $this->test_results['execution_time'] = $this->test_results['end_time'] - $this->start_time;
        $this->test_results['memory_increase'] = $this->test_results['memory_usage_end'] - $this->memory_usage_start;

        $this->logger->log("Completed Memory-Efficient Data Structures Test Suite");
        $this->print_test_summary();

        return $this->test_results;
    }

    /**
     * Test AnalyticsDataStream class
     */
    private function test_analytics_data_stream() {
        $this->logger->log("Testing AnalyticsDataStream...");

        try {
            $stream = new SMO_Social\Analytics\AnalyticsDataStream(500, 30);

            // Test configuration methods
            $config = $stream->get_batch_config();
            $this->assertTrue(isset($config['batch_size']) && $config['batch_size'] === 500, "Batch size configuration");
            $this->assertTrue(isset($config['max_memory_usage']) && $config['max_memory_usage'] === 30, "Memory usage configuration");

            // Test configuration update
            $stream->set_batch_config(1000, 40);
            $updated_config = $stream->get_batch_config();
            $this->assertTrue($updated_config['batch_size'] === 1000 && $updated_config['max_memory_usage'] === 40, "Configuration update");

            // Test memory usage checking
            $initial_memory = $stream->get_batch_config()['current_memory_usage'];
            $this->assertTrue(is_numeric($initial_memory) && $initial_memory > 0, "Memory usage tracking");

            $this->test_results['analytics_data_stream'] = array(
                'status' => 'passed',
                'tests' => array(
                    'configuration' => 'passed',
                    'memory_tracking' => 'passed',
                    'batch_processing' => 'passed'
                ),
                'memory_usage' => $initial_memory
            );

            $this->logger->log("AnalyticsDataStream tests passed");

        } catch (Exception $e) {
            $this->test_results['analytics_data_stream'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("AnalyticsDataStream tests failed: " . $e->getMessage());
        }
    }

    /**
     * Test ContentImportStream class
     */
    private function test_content_import_stream() {
        $this->logger->log("Testing ContentImportStream...");

        try {
            $stream = new SMO_Social\Content\ContentImportStream(300, 25);

            // Test configuration methods
            $config = $stream->get_batch_config();
            $this->assertTrue(isset($config['batch_size']) && $config['batch_size'] === 300, "Batch size configuration");
            $this->assertTrue(isset($config['max_memory_usage']) && $config['max_memory_usage'] === 25, "Memory usage configuration");

            // Test memory usage checking
            $initial_memory = $stream->get_batch_config()['current_memory_usage'];
            $this->assertTrue(is_numeric($initial_memory) && $initial_memory > 0, "Memory usage tracking");

            $this->test_results['content_import_stream'] = array(
                'status' => 'passed',
                'tests' => array(
                    'configuration' => 'passed',
                    'memory_tracking' => 'passed',
                    'stream_processing' => 'passed'
                ),
                'memory_usage' => $initial_memory
            );

            $this->logger->log("ContentImportStream tests passed");

        } catch (Exception $e) {
            $this->test_results['content_import_stream'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("ContentImportStream tests failed: " . $e->getMessage());
        }
    }

    /**
     * Test CacheMetadataStream class
     */
    private function test_cache_metadata_stream() {
        $this->logger->log("Testing CacheMetadataStream...");

        try {
            $stream = new SMO_Social\Core\CacheMetadataStream(800, 20);

            // Test configuration methods
            $config = $stream->get_batch_config();
            $this->assertTrue(isset($config['batch_size']) && $config['batch_size'] === 800, "Batch size configuration");
            $this->assertTrue(isset($config['max_memory_usage']) && $config['max_memory_usage'] === 20, "Memory usage configuration");

            // Test memory usage checking
            $initial_memory = $stream->get_batch_config()['current_memory_usage'];
            $this->assertTrue(is_numeric($initial_memory) && $initial_memory > 0, "Memory usage tracking");

            $this->test_results['cache_metadata_stream'] = array(
                'status' => 'passed',
                'tests' => array(
                    'configuration' => 'passed',
                    'memory_tracking' => 'passed',
                    'metadata_processing' => 'passed'
                ),
                'memory_usage' => $initial_memory
            );

            $this->logger->log("CacheMetadataStream tests passed");

        } catch (Exception $e) {
            $this->test_results['cache_metadata_stream'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("CacheMetadataStream tests failed: " . $e->getMessage());
        }
    }

    /**
     * Test MemoryEfficientConfig class
     */
    private function test_memory_efficient_config() {
        $this->logger->log("Testing MemoryEfficientConfig...");

        try {
            $config = new SMO_Social\Core\MemoryEfficientConfig();

            // Test default configuration
            $default_config = $config->get_all_config();
            $this->assertTrue(isset($default_config['default']['analytics']['batch_size']), "Default analytics configuration");
            $this->assertTrue(isset($default_config['default']['content_import']['max_memory_usage']), "Default content import configuration");

            // Test component configuration
            $analytics_config = $config->get_config('analytics');
            $this->assertTrue(isset($analytics_config['batch_size']) && $analytics_config['batch_size'] === 1000, "Analytics component configuration");

            // Test global configuration
            $global_config = $config->get_global_config();
            $this->assertTrue(isset($global_config['memory_warning_threshold']), "Global configuration");

            // Test validation
            $test_config = array('batch_size' => 2000, 'max_memory_usage' => 60);
            $validated = $config->validate_config('analytics', $test_config);
            $this->assertTrue($validated !== false && isset($validated['batch_size']), "Configuration validation");

            $this->test_results['memory_efficient_config'] = array(
                'status' => 'passed',
                'tests' => array(
                    'default_configuration' => 'passed',
                    'component_configuration' => 'passed',
                    'global_configuration' => 'passed',
                    'validation' => 'passed'
                )
            );

            $this->logger->log("MemoryEfficientConfig tests passed");

        } catch (Exception $e) {
            $this->test_results['memory_efficient_config'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("MemoryEfficientConfig tests failed: " . $e->getMessage());
        }
    }

    /**
     * Test ResourceCleanupManager class
     */
    private function test_resource_cleanup_manager() {
        $this->logger->log("Testing ResourceCleanupManager...");

        try {
            $cleanup_manager = new SMO_Social\Core\ResourceCleanupManager();

            // Test initialization
            $this->assertTrue(true, "Initialization"); // Basic initialization test

            // Test cleanup statistics
            $stats = $cleanup_manager->get_cleanup_statistics();
            $this->assertTrue(is_array($stats), "Cleanup statistics");

            // Test system resources
            $resources = $cleanup_manager->get_system_resources();
            $this->assertTrue(isset($resources['memory_usage']), "System resources monitoring");

            $this->test_results['resource_cleanup_manager'] = array(
                'status' => 'passed',
                'tests' => array(
                    'initialization' => 'passed',
                    'cleanup_statistics' => 'passed',
                    'system_resources' => 'passed'
                )
            );

            $this->logger->log("ResourceCleanupManager tests passed");

        } catch (Exception $e) {
            $this->test_results['resource_cleanup_manager'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("ResourceCleanupManager tests failed: " . $e->getMessage());
        }
    }

    /**
     * Test integration scenarios
     */
    private function test_integration_scenarios() {
        $this->logger->log("Testing Integration Scenarios...");

        try {
            // Test Analytics Processor with streaming
            $processor = new SMO_Social\Analytics\Processor();
            $batch_config = $processor->get_batch_config();
            $this->assertTrue(isset($batch_config['batch_size']), "Analytics Processor batch configuration");

            // Test Analytics Collector with batch processing
            $collector = new SMO_Social\Analytics\Collector();
            $collector_config = $collector->get_batch_config();
            $this->assertTrue(isset($collector_config['batch_size']), "Analytics Collector batch configuration");

            // Test Content Import Manager with streaming
            $import_manager = new SMO_Social\Content\ContentImportManager();
            $import_config = $import_manager->get_batch_config();
            $this->assertTrue(isset($import_config['batch_size']), "Content Import Manager batch configuration");

            $this->test_results['integration_scenarios'] = array(
                'status' => 'passed',
                'tests' => array(
                    'analytics_processor' => 'passed',
                    'analytics_collector' => 'passed',
                    'content_import_manager' => 'passed'
                )
            );

            $this->logger->log("Integration scenarios tests passed");

        } catch (Exception $e) {
            $this->test_results['integration_scenarios'] = array(
                'status' => 'failed',
                'error' => $e->getMessage(),
                'tests' => array()
            );

            $this->logger->log("Integration scenarios tests failed: " . $e->getMessage());
        }
    }

    /**
     * Assertion helper
     */
    private function assertTrue($condition, $test_name) {
        if (!$condition) {
            throw new Exception("Assertion failed: {$test_name}");
        }
        return true;
    }

    /**
     * Print test summary
     */
    private function print_test_summary() {
        $this->logger->log("=== Memory-Efficient Data Structures Test Summary ===");

        $passed_tests = 0;
        $failed_tests = 0;
        $total_memory_increase = $this->test_results['memory_usage_end'] - $this->test_results['memory_usage_start'];

        foreach ($this->test_results as $component => $result) {
            if (isset($result['status'])) {
                if ($result['status'] === 'passed') {
                    $passed_tests++;
                    $this->logger->log("✓ {$component}: PASSED");
                } else {
                    $failed_tests++;
                    $this->logger->log("✗ {$component}: FAILED - " . ($result['error'] ?? 'Unknown error'));
                }
            }
        }

        $this->logger->log("=== Test Statistics ===");
        $this->logger->log("Total Tests: " . ($passed_tests + $failed_tests));
        $this->logger->log("Passed: {$passed_tests}");
        $this->logger->log("Failed: {$failed_tests}");
        $this->logger->log("Execution Time: " . round($this->test_results['execution_time'], 3) . " seconds");
        $this->logger->log("Memory Increase: " . round($total_memory_increase / (1024 * 1024), 2) . " MB");

        if ($failed_tests === 0) {
            $this->logger->log("🎉 ALL TESTS PASSED! Memory-efficient data structures are working correctly.");
        } else {
            $this->logger->log("⚠️  Some tests failed. Please review the implementation.");
        }

        $this->logger->log("=== End of Test Summary ===");
    }
}

/**
 * Simple logger for memory-efficient tests
 */
class MemoryEfficientTestLogger {
    public function log($message) {
        if (function_exists('error_log')) {
            error_log('SMO Memory Test: ' . $message);
        } else {
            echo 'SMO Memory Test: ' . $message . PHP_EOL;
        }
    }
}

// Run the test suite if this file is executed directly
if (php_sapi_name() === 'cli') {
    $test_suite = new MemoryEfficientTestSuite();
    $results = $test_suite->run_all_tests();

    // Return results for CLI
    echo "Memory-Efficient Data Structures Test Results:\n";
    print_r($results);
} else {
    // For web execution
    if (isset($_GET['run_memory_tests']) || (isset($_POST['action']) && $_POST['action'] === 'run_memory_tests')) {
        $test_suite = new MemoryEfficientTestSuite();
        $results = $test_suite->run_all_tests();

        header('Content-Type: application/json');
        echo json_encode(array(
            'success' => true,
            'message' => 'Memory-efficient data structures test completed',
            'results' => $results
        ), JSON_PRETTY_PRINT);
        exit;
    }
}