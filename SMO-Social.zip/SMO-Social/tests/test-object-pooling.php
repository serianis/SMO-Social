<?php
/**
 * Object Pooling Test Suite for SMO Social
 *
 * Tests the object pooling implementation
 *
 * @package SMO_Social
 * @subpackage Tests
 */

if (!defined('ABSPATH')) {
    exit;
}

// Include necessary files
require_once __DIR__ . '/../includes/Core/DatabaseConnectionPool.php';
require_once __DIR__ . '/../includes/Core/CacheObjectPool.php';
require_once __DIR__ . '/../includes/WebSocket/WebSocketConnectionPool.php';
require_once __DIR__ . '/../includes/Core/ObjectPoolConfig.php';
require_once __DIR__ . '/../includes/Core/ObjectPoolMonitor.php';

class ObjectPoolingTest {
    public function run_all_tests() {
        echo "Starting Object Pooling Tests...\n";

        $this->test_database_connection_pool();
        $this->test_cache_object_pool();
        $this->test_websocket_connection_pool();
        $this->test_object_pool_config();
        $this->test_object_pool_monitor();

        echo "All tests completed!\n";
    }

    private function test_database_connection_pool() {
        echo "\n=== Testing Database Connection Pool ===\n";

        try {
            $pool = new \SMO_Social\Core\DatabaseConnectionPool([], 5);

            // Test initial pool size
            $initial_size = $pool->get_current_pool_size();
            echo "Initial pool size: $initial_size\n";

            // Test getting connections
            $conn1 = $pool->get_connection();
            $conn2 = $pool->get_connection();

            if ($conn1 && $conn2) {
                echo "Successfully got 2 connections from pool\n";
            } else {
                echo "Failed to get connections from pool\n";
            }

            // Test releasing connections
            $pool->release_connection($conn1);
            $pool->release_connection($conn2);

            // Test pool statistics
            $stats = $pool->get_stats();
            echo "Pool stats: " . print_r($stats, true) . "\n";

            // Test cleanup
            $pool->cleanup_idle_connections(1);
            echo "Cleanup performed\n";

            echo "Database Connection Pool Test: PASSED\n";

        } catch (Exception $e) {
            echo "Database Connection Pool Test: FAILED - " . $e->getMessage() . "\n";
        }
    }

    private function test_cache_object_pool() {
        echo "\n=== Testing Cache Object Pool ===\n";

        try {
            $pool = new \SMO_Social\Core\CacheObjectPool(10, 300);

            // Test initial pool size
            $initial_size = $pool->get_current_pool_size();
            echo "Initial pool size: $initial_size\n";

            // Test getting cache objects
            $obj1 = $pool->get_cache_object();
            $obj2 = $pool->get_cache_object_with_data(['test' => 'data']);

            if ($obj1 && $obj2) {
                echo "Successfully got 2 cache objects from pool\n";
            } else {
                echo "Failed to get cache objects from pool\n";
            }

            // Test releasing objects
            $pool->release_cache_object($obj1);
            $pool->release_cache_object($obj2);

            // Test pool statistics
            $stats = $pool->get_stats();
            echo "Pool stats: " . print_r($stats, true) . "\n";

            // Test cleanup
            $pool->cleanup_idle_objects(1);
            echo "Cleanup performed\n";

            echo "Cache Object Pool Test: PASSED\n";

        } catch (Exception $e) {
            echo "Cache Object Pool Test: FAILED - " . $e->getMessage() . "\n";
        }
    }

    private function test_websocket_connection_pool() {
        echo "\n=== Testing WebSocket Connection Pool ===\n";

        try {
            $config = [
                'host' => '127.0.0.1',
                'port' => 8080,
                'timeout' => 300
            ];

            $pool = new \SMO_Social\WebSocket\WebSocketConnectionPool($config, 10);

            // Test initial pool size
            $initial_size = $pool->get_current_pool_size();
            echo "Initial pool size: $initial_size\n";

            // Test getting connections
            $conn1 = $pool->get_connection();
            $conn2 = $pool->get_connected_connection();

            if ($conn1 && $conn2) {
                echo "Successfully got 2 connections from pool\n";
            } else {
                echo "Failed to get connections from pool\n";
            }

            // Test releasing connections
            $pool->release_connection($conn1);
            $pool->release_connection($conn2);

            // Test pool statistics
            $stats = $pool->get_stats();
            echo "Pool stats: " . print_r($stats, true) . "\n";

            // Test cleanup
            $pool->cleanup_idle_connections(1);
            echo "Cleanup performed\n";

            echo "WebSocket Connection Pool Test: PASSED\n";

        } catch (Exception $e) {
            echo "WebSocket Connection Pool Test: FAILED - " . $e->getMessage() . "\n";
        }
    }

    private function test_object_pool_config() {
        echo "\n=== Testing Object Pool Config ===\n";

        try {
            // Test getting default configs
            $default_configs = \SMO_Social\Core\ObjectPoolConfig::get_default_configs();
            echo "Default configs retrieved: " . count($default_configs) . " pools\n";

            // Test getting specific pool config
            $db_config = \SMO_Social\Core\ObjectPoolConfig::get_pool_config('database_pool');
            echo "Database pool config: " . print_r($db_config, true) . "\n";

            // Test validation rules
            $rules = \SMO_Social\Core\ObjectPoolConfig::get_validation_rules();
            echo "Validation rules retrieved: " . count($rules) . " pools\n";

            // Test admin configs
            $admin_configs = \SMO_Social\Core\ObjectPoolConfig::get_admin_pool_configs();
            echo "Admin configs retrieved: " . count($admin_configs) . " pools\n";

            echo "Object Pool Config Test: PASSED\n";

        } catch (Exception $e) {
            echo "Object Pool Config Test: FAILED - " . $e->getMessage() . "\n";
        }
    }

    private function test_object_pool_monitor() {
        echo "\n=== Testing Object Pool Monitor ===\n";

        try {
            $monitor = \SMO_Social\Core\ObjectPoolMonitor::get_instance();

            // Test getting current stats
            $stats = $monitor->get_current_stats();
            echo "Current stats retrieved: " . count($stats['pools']) . " pools\n";

            // Test getting system health
            $health = $monitor->get_system_health();
            echo "System health status: " . $health['status'] . "\n";

            // Test getting performance metrics
            $metrics = $monitor->get_performance_metrics();
            echo "Performance metrics: " . print_r($metrics, true) . "\n";

            // Test getting monitoring config
            $config = $monitor->get_monitoring_config();
            echo "Monitoring config: " . print_r($config, true) . "\n";

            // Test force cleanup
            $monitor->force_cleanup();
            echo "Force cleanup performed\n";

            echo "Object Pool Monitor Test: PASSED\n";

        } catch (Exception $e) {
            echo "Object Pool Monitor Test: FAILED - " . $e->getMessage() . "\n";
        }
    }
}

// Run the tests
if (php_sapi_name() === 'cli') {
    $test = new ObjectPoolingTest();
    $test->run_all_tests();
} else {
    echo "This test should be run from the command line.";
}