<?php
// Test OpenRouter Connection
$api_key = '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';
$model = 'kwaipilot/kat-coder-pro:free';

$url = 'https://openrouter.ai/api/v1/chat/completions';

$headers = [
    'Authorization: Bearer ' . $api_key,
    'Content-Type: application/json',
    'HTTP-Referer: http://localhost', // Mock
    'X-Title: SMO Social Test'
];

$data = [
    'model' => $model,
    'messages' => [
        ['role' => 'user', 'content' => 'Hello, are you working?']
    ]
];

echo "Testing OpenRouter connection...\n";
echo "URL: $url\n";
echo "Model: $model\n";

$ch = curl_init($url);
curl_setopt($ch, CURLOPT_RETURNTRANSFER, true);
curl_setopt($ch, CURLOPT_POST, true);
curl_setopt($ch, CURLOPT_POSTFIELDS, json_encode($data));
curl_setopt($ch, CURLOPT_HTTPHEADER, $headers);
curl_setopt($ch, CURLOPT_SSL_VERIFYPEER, false); // Disable SSL check for testing

$response = curl_exec($ch);
$error = curl_error($ch);
$info = curl_getinfo($ch);

curl_close($ch);

if ($error) {
    echo "Error: $error\n";
} else {
    echo "Status Code: " . $info['http_code'] . "\n";
    echo "Response: $response\n";
}
