<?php
/**
 * PHP Backend Test Suite
 *
 * This test suite verifies all PHP backend functionality, AJAX handlers,
 * and database operations for the Content Organizer.
 */

// Set headers for JSON response
header('Content-Type: application/json');

// Include necessary files
require_once __DIR__ . '/includes/wordpress-functions.php';
require_once __DIR__ . '/includes/consolidated-db-stubs.php';
require_once __DIR__ . '/includes/EnvironmentDetector.php';
require_once __DIR__ . '/includes/Admin/Admin.php';
require_once __DIR__ . '/includes/Content/ContentCategoriesManager.php';
require_once __DIR__ . '/includes/Content/ContentIdeasManager.php';

// Initialize test results array
$testResults = array(
    'ajax_handlers' => array(),
    'database_operations' => array(),
    'error_handling' => array(),
    'security' => array(),
    'performance' => array()
);

// Mock WordPress environment
if (!function_exists('wp_send_json_success')) {
    function wp_send_json_success($data) {
        echo json_encode(array('success' => true, 'data' => $data));
        exit;
    }
}

if (!function_exists('wp_send_json_error')) {
    function wp_send_json_error($message, $code = 400) {
        echo json_encode(array('success' => false, 'error' => $message));
        exit;
    }
}

if (!function_exists('check_ajax_referer')) {
    function check_ajax_referer($action, $query_arg = false) {
        // Mock nonce validation - always pass for testing
        return true;
    }
}

if (!function_exists('current_user_can')) {
    function current_user_can($capability) {
        // Mock user capability - always return true for testing
        return true;
    }
}

if (!function_exists('get_current_user_id')) {
    function get_current_user_id() {
        // Mock current user ID
        return 1;
    }
}

// Initialize Admin class for AJAX handlers
$admin = new SMO_Social\Admin\Admin();

// Initialize Content Managers
$categoriesManager = new SMO_Social\Content\ContentCategoriesManager();
$ideasManager = new SMO_Social\Content\ContentIdeasManager();

// Test AJAX Handlers
function testAJAXHandlers() {
    global $admin, $testResults;

    // Test 1: Get Organizer Stats
    try {
        ob_start();
        $admin->ajax_get_organizer_stats();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            $testResults['ajax_handlers']['stats'] = array(
                'status' => 'pass',
                'message' => 'Organizer stats AJAX handler working correctly',
                'data' => $data['data']
            );
        } else {
            $testResults['ajax_handlers']['stats'] = array(
                'status' => 'fail',
                'message' => 'Organizer stats AJAX handler failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['ajax_handlers']['stats'] = array(
            'status' => 'error',
            'message' => 'Organizer stats AJAX handler error: ' . $e->getMessage()
        );
    }

    // Test 2: Get Categories
    try {
        ob_start();
        $admin->ajax_get_categories();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            $testResults['ajax_handlers']['categories'] = array(
                'status' => 'pass',
                'message' => 'Get categories AJAX handler working correctly',
                'count' => count($data['data'])
            );
        } else {
            $testResults['ajax_handlers']['categories'] = array(
                'status' => 'fail',
                'message' => 'Get categories AJAX handler failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['ajax_handlers']['categories'] = array(
            'status' => 'error',
            'message' => 'Get categories AJAX handler error: ' . $e->getMessage()
        );
    }

    // Test 3: Save Category
    try {
        $_POST['name'] = 'Test Category';
        $_POST['description'] = 'Test Description';
        $_POST['color'] = '#667eea';
        $_POST['icon'] = '📁';

        ob_start();
        $admin->ajax_save_category();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            $testResults['ajax_handlers']['save_category'] = array(
                'status' => 'pass',
                'message' => 'Save category AJAX handler working correctly',
                'category_id' => $data['data']['id']
            );
        } else {
            $testResults['ajax_handlers']['save_category'] = array(
                'status' => 'fail',
                'message' => 'Save category AJAX handler failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['ajax_handlers']['save_category'] = array(
            'status' => 'error',
            'message' => 'Save category AJAX handler error: ' . $e->getMessage()
        );
    }

    // Test 4: Get Ideas
    try {
        ob_start();
        $admin->ajax_get_ideas();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            $testResults['ajax_handlers']['ideas'] = array(
                'status' => 'pass',
                'message' => 'Get ideas AJAX handler working correctly',
                'data' => $data['data']
            );
        } else {
            $testResults['ajax_handlers']['ideas'] = array(
                'status' => 'fail',
                'message' => 'Get ideas AJAX handler failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['ajax_handlers']['ideas'] = array(
            'status' => 'error',
            'message' => 'Get ideas AJAX handler error: ' . $e->getMessage()
        );
    }
}

// Test Database Operations
function testDatabaseOperations() {
    global $categoriesManager, $ideasManager, $testResults;

    // Test 1: Category CRUD Operations
    try {
        // Create a test category
        $categoryData = array(
            'name' => 'Test Category',
            'description' => 'Test Description',
            'color_code' => '#667eea',
            'icon' => '📁'
        );

        $categoryId = $categoriesManager->add_category($categoryData);

        if ($categoryId) {
            $testResults['database_operations']['create_category'] = array(
                'status' => 'pass',
                'message' => 'Category creation successful',
                'category_id' => $categoryId
            );

            // Read the category
            $categories = $categoriesManager->get_categories();
            $foundCategory = null;

            foreach ($categories as $category) {
                if ($category['id'] == $categoryId) {
                    $foundCategory = $category;
                    break;
                }
            }

            if ($foundCategory) {
                $testResults['database_operations']['read_category'] = array(
                    'status' => 'pass',
                    'message' => 'Category retrieval successful',
                    'category' => $foundCategory
                );

                // Update the category
                $updateResult = $categoriesManager->update_category($categoryId, array(
                    'name' => 'Updated Test Category'
                ));

                if ($updateResult) {
                    $testResults['database_operations']['update_category'] = array(
                        'status' => 'pass',
                        'message' => 'Category update successful'
                    );

                    // Delete the category
                    $deleteResult = $categoriesManager->delete_category($categoryId);

                    if ($deleteResult) {
                        $testResults['database_operations']['delete_category'] = array(
                            'status' => 'pass',
                            'message' => 'Category deletion successful'
                        );
                    } else {
                        $testResults['database_operations']['delete_category'] = array(
                            'status' => 'fail',
                            'message' => 'Category deletion failed'
                        );
                    }
                } else {
                    $testResults['database_operations']['update_category'] = array(
                        'status' => 'fail',
                        'message' => 'Category update failed'
                    );
                }
            } else {
                $testResults['database_operations']['read_category'] = array(
                    'status' => 'fail',
                    'message' => 'Category retrieval failed'
                );
            }
        } else {
            $testResults['database_operations']['create_category'] = array(
                'status' => 'fail',
                'message' => 'Category creation failed'
            );
        }
    } catch (Exception $e) {
        $testResults['database_operations']['category_crud'] = array(
            'status' => 'error',
            'message' => 'Category CRUD operations error: ' . $e->getMessage()
        );
    }

    // Test 2: Idea CRUD Operations
    try {
        // Create a test idea
        $ideaData = array(
            'title' => 'Test Idea',
            'description' => 'Test Idea Description',
            'content_type' => 'post',
            'target_platforms' => array('twitter', 'facebook'),
            'tags' => array('test', 'idea'),
            'category' => 'Test Category',
            'priority' => 'medium',
            'status' => 'idea'
        );

        $ideaId = $ideasManager->add_content_idea($ideaData);

        if ($ideaId) {
            $testResults['database_operations']['create_idea'] = array(
                'status' => 'pass',
                'message' => 'Idea creation successful',
                'idea_id' => $ideaId
            );

            // Read the idea
            $ideas = $ideasManager->get_content_ideas();
            $foundIdea = null;

            foreach ($ideas as $idea) {
                if ($idea['id'] == $ideaId) {
                    $foundIdea = $idea;
                    break;
                }
            }

            if ($foundIdea) {
                $testResults['database_operations']['read_idea'] = array(
                    'status' => 'pass',
                    'message' => 'Idea retrieval successful',
                    'idea' => $foundIdea
                );

                // Update the idea
                $updateResult = $ideasManager->update_content_idea($ideaId, array(
                    'title' => 'Updated Test Idea'
                ));

                if ($updateResult) {
                    $testResults['database_operations']['update_idea'] = array(
                        'status' => 'pass',
                        'message' => 'Idea update successful'
                    );

                    // Delete the idea
                    $deleteResult = $ideasManager->delete_content_idea($ideaId);

                    if ($deleteResult) {
                        $testResults['database_operations']['delete_idea'] = array(
                            'status' => 'pass',
                            'message' => 'Idea deletion successful'
                        );
                    } else {
                        $testResults['database_operations']['delete_idea'] = array(
                            'status' => 'fail',
                            'message' => 'Idea deletion failed'
                        );
                    }
                } else {
                    $testResults['database_operations']['update_idea'] = array(
                        'status' => 'fail',
                        'message' => 'Idea update failed'
                    );
                }
            } else {
                $testResults['database_operations']['read_idea'] = array(
                    'status' => 'fail',
                    'message' => 'Idea retrieval failed'
                );
            }
        } else {
            $testResults['database_operations']['create_idea'] = array(
                'status' => 'fail',
                'message' => 'Idea creation failed'
            );
        }
    } catch (Exception $e) {
        $testResults['database_operations']['idea_crud'] = array(
            'status' => 'error',
            'message' => 'Idea CRUD operations error: ' . $e->getMessage()
        );
    }
}

// Test Error Handling
function testErrorHandling() {
    global $testResults, $categoriesManager, $admin;

    // Test 1: Invalid Input Handling
    try {
        // Test with invalid data
        $_POST['name'] = ''; // Empty name should fail validation

        ob_start();
        $admin->ajax_save_category();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && !$data['success']) {
            $testResults['error_handling']['invalid_input'] = array(
                'status' => 'pass',
                'message' => 'Invalid input handling working correctly',
                'error' => $data['error']
            );
        } else {
            $testResults['error_handling']['invalid_input'] = array(
                'status' => 'fail',
                'message' => 'Invalid input handling failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['error_handling']['invalid_input'] = array(
            'status' => 'error',
            'message' => 'Invalid input handling error: ' . $e->getMessage()
        );
    }

    // Test 2: Database Error Handling
    try {
        // Test with invalid category ID for deletion
        $result = $categoriesManager->delete_category(999999); // Non-existent ID

        if (!$result) {
            $testResults['error_handling']['database_error'] = array(
                'status' => 'pass',
                'message' => 'Database error handling working correctly'
            );
        } else {
            $testResults['error_handling']['database_error'] = array(
                'status' => 'fail',
                'message' => 'Database error handling failed - should not delete non-existent record'
            );
        }
    } catch (Exception $e) {
        $testResults['error_handling']['database_error'] = array(
            'status' => 'pass',
            'message' => 'Database error handling working correctly',
            'error' => $e->getMessage()
        );
    }
}

// Test Security
function testSecurity() {
    global $testResults, $categoriesManager, $admin;

    // Test 1: Nonce Validation
    try {
        // Test with missing nonce
        $_POST['nonce'] = ''; // Empty nonce

        ob_start();
        $admin->ajax_save_category();
        $response = ob_get_clean();

        // Check if security validation failed
        $data = json_decode($response, true);
        if ($data && isset($data['success']) && !$data['success']) {
            $testResults['security']['nonce_validation'] = array(
                'status' => 'pass',
                'message' => 'Nonce validation working correctly'
            );
        } else {
            $testResults['security']['nonce_validation'] = array(
                'status' => 'fail',
                'message' => 'Nonce validation failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['security']['nonce_validation'] = array(
            'status' => 'error',
            'message' => 'Nonce validation error: ' . $e->getMessage()
        );
    }

    // Test 2: Input Sanitization
    try {
        // Test with potentially malicious input
        $_POST['name'] = '<script>alert("XSS")</script>Test Category';

        ob_start();
        $admin->ajax_save_category();
        $response = ob_get_clean();

        $data = json_decode($response, true);
        if ($data && isset($data['success']) && $data['success']) {
            // Check if the script tag was sanitized
            $categoryId = $data['data']['id'];
            $categories = $categoriesManager->get_categories();

            $foundCategory = null;
            foreach ($categories as $category) {
                if ($category['id'] == $categoryId) {
                    $foundCategory = $category;
                    break;
                }
            }

            if ($foundCategory && strpos($foundCategory['name'], '<script>') === false) {
                $testResults['security']['input_sanitization'] = array(
                    'status' => 'pass',
                    'message' => 'Input sanitization working correctly',
                    'sanitized_name' => $foundCategory['name']
                );

                // Clean up
                $categoriesManager->delete_category($categoryId);
            } else {
                $testResults['security']['input_sanitization'] = array(
                    'status' => 'fail',
                    'message' => 'Input sanitization failed',
                    'category_name' => $foundCategory ? $foundCategory['name'] : 'Category not found'
                );
            }
        } else {
            $testResults['security']['input_sanitization'] = array(
                'status' => 'fail',
                'message' => 'Input sanitization test failed',
                'response' => $response
            );
        }
    } catch (Exception $e) {
        $testResults['security']['input_sanitization'] = array(
            'status' => 'error',
            'message' => 'Input sanitization error: ' . $e->getMessage()
        );
    }
}

// Test Performance
function testPerformance() {
    global $testResults, $categoriesManager;

    // Test 1: Bulk Operations Performance
    try {
        $startTime = microtime(true);

        // Create multiple categories for performance test
        $categoryIds = array();
        for ($i = 0; $i < 10; $i++) {
            $categoryId = $categoriesManager->add_category(array(
                'name' => 'Performance Test Category ' . $i,
                'description' => 'Performance test description',
                'color_code' => '#667eea',
                'icon' => '📁'
            ));
            $categoryIds[] = $categoryId;
        }

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        // Clean up
        foreach ($categoryIds as $categoryId) {
            $categoriesManager->delete_category($categoryId);
        }

        $testResults['performance']['bulk_operations'] = array(
            'status' => 'pass',
            'message' => 'Bulk operations performance test completed',
            'execution_time' => $executionTime,
            'operations' => 10,
            'avg_time_per_operation' => $executionTime / 10
        );
    } catch (Exception $e) {
        $testResults['performance']['bulk_operations'] = array(
            'status' => 'error',
            'message' => 'Bulk operations performance test error: ' . $e->getMessage()
        );
    }

    // Test 2: Data Retrieval Performance
    try {
        $startTime = microtime(true);

        // Retrieve categories multiple times
        for ($i = 0; $i < 100; $i++) {
            $categories = $categoriesManager->get_categories();
        }

        $endTime = microtime(true);
        $executionTime = $endTime - $startTime;

        $testResults['performance']['data_retrieval'] = array(
            'status' => 'pass',
            'message' => 'Data retrieval performance test completed',
            'execution_time' => $executionTime,
            'operations' => 100,
            'avg_time_per_operation' => $executionTime / 100
        );
    } catch (Exception $e) {
        $testResults['performance']['data_retrieval'] = array(
            'status' => 'error',
            'message' => 'Data retrieval performance test error: ' . $e->getMessage()
        );
    }
}

// Run all tests
testAJAXHandlers();
testDatabaseOperations();
testErrorHandling();
testSecurity();
testPerformance();

// Generate test report
function generateTestReport() {
    global $testResults;

    $report = array(
        'timestamp' => date('Y-m-d H:i:s'),
        'test_results' => $testResults,
        'summary' => array(
            'total_tests' => 0,
            'passed' => 0,
            'failed' => 0,
            'errors' => 0,
            'success_rate' => 0
        )
    );

    // Calculate summary
    foreach ($testResults as $category => $tests) {
        foreach ($tests as $test => $result) {
            $report['summary']['total_tests']++;

            if ($result['status'] === 'pass') {
                $report['summary']['passed']++;
            } elseif ($result['status'] === 'fail') {
                $report['summary']['failed']++;
            } else {
                $report['summary']['errors']++;
            }
        }
    }

    // Calculate success rate
    if ($report['summary']['total_tests'] > 0) {
        $report['summary']['success_rate'] = ($report['summary']['passed'] / $report['summary']['total_tests']) * 100;
    }

    return $report;
}

// Output the test report
$testReport = generateTestReport();

// Return JSON response
echo json_encode(array(
    'success' => true,
    'message' => 'PHP Backend Test Suite Completed',
    'test_report' => $testReport
), JSON_PRETTY_PRINT);